<?php
/**
 * ****************************************************************************
 *
 *   DON'T EDIT THIS FILE
 *   After update you will lose all changes. Use child theme
 *
 *   НЕ РЕДАКТИРУЙТЕ ЭТОТ ФАЙЛ
 *   После обновления Вы потереяете все изменения. Используйте дочернюю тему
 *
 *   https://support.wpshop.ru/docs/general/child-themes/
 *
 * *****************************************************************************
 *
 * @package journalx
 */

global $wpshop_core;
global $wpshop_advertising;

$is_show_header = $wpshop_core->is_show_element( 'header' );

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
    <?php $wpshop_core->the_option( 'code_head' ) ?>
</head>

<body <?php body_class(); ?>>
<?php $wpshop_core->check_license() ?>

<?php if ( function_exists( 'wp_body_open' ) ) {
    wp_body_open();
} else {
    do_action( 'wp_body_open' );
} ?>

<?php do_action( THEME_SLUG . '_after_body' ) ?>

<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><!--noindex--><?php esc_html_e( 'Skip to content', THEME_TEXTDOMAIN ); ?><!--/noindex--></a>

    <?php
    if ( $is_show_header ) {
        get_template_part( 'template/header/header' );
    } ?>

    <div class="mobile-menu-placeholder js-mobile-menu-placeholder"></div>

    <div class="search-screen js-search-screen">
        <?php get_search_form() ?>
    </div>

    <?php do_action( THEME_SLUG . '_before_site_content' ) ?>

    <?php echo $wpshop_advertising->show_ad( 'before_site_content' ); ?>

	<div id="content" class="site-content">
