<?php
/**
 * ****************************************************************************
 *
 *   DON'T EDIT THIS FILE
 *   After update you will lose all changes. Use child theme
 *
 *   НЕ РЕДАКТИРУЙТЕ ЭТОТ ФАЙЛ
 *   После обновления Вы потереяете все изменения. Используйте дочернюю тему
 *
 *   https://support.wpshop.ru/docs/general/child-themes/
 *
 * *****************************************************************************
 *
 * @package journalx
 */

get_header(); ?>

	<section id="primary" class="content-area">
		<main id="main" class="site-main">

		    <?php
		    if ( have_posts() ) : ?>

			    <header class="page-header">
                    <h1 class="page-title"><?php echo apply_filters( THEME_SLUG . '_search_with_results_title', __( 'Search results for', THEME_TEXTDOMAIN ) ), ': <span>' . get_search_query() . '</span>' ?></h1>
                </header><!-- .page-header -->

                <div class="post-boxes">

			    <?php
			    while ( have_posts() ) : the_post();

                    get_template_part( 'template/content', get_post_format() );

			    endwhile;
			    ?>

                </div>

                <?php
                the_posts_pagination();

		    else :

			    get_template_part( 'template/content', 'none' );

		    endif; ?>

		</main><!-- #main -->
	</section><!-- #primary -->

<?php
get_sidebar();
get_footer();
