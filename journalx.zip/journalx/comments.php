<?php
/**
 * ****************************************************************************
 *
 *   DON'T EDIT THIS FILE
 *   After update you will lose all changes. Use child theme
 *
 *   НЕ РЕДАКТИРУЙТЕ ЭТОТ ФАЙЛ
 *   После обновления Вы потереяете все изменения. Используйте дочернюю тему
 *
 *   https://support.wpshop.ru/docs/general/child-themes/
 *
 * *****************************************************************************
 *
 * @package journalx
 */

global $wpshop_core;

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
$class_journalx_comments = new JournalX_Comments();
?>

<div id="comments" class="comments-area">

	<?php
	// You can start editing here -- including this comment!
	if ( have_comments() ) : ?>
        <?php /*<div class="comments-title"><?php _e( 'Comments', THEME_TEXTDOMAIN ) ?>: <?php echo get_comments_number() ?></div>*/ ?>

		<?php $class_journalx_comments->the_comments_pagination(); ?>

        <ol class="comment-list">
            <?php
            wp_list_comments( array(
                'type'     => 'comment',
                'style'    => 'ol',
                'callback' => 'vetteo_comment',
            ) );
            ?>
        </ol><!-- .comment-list -->

        <?php $class_journalx_comments->the_comments_pagination();

		// If comments are closed and there are comments, let's leave a little note, shall we?
		if ( ! comments_open() ) : ?>
			<p class="no-comments">
                <?php echo apply_filters( THEME_SLUG . '_comments_no_comments_title', __( 'Comments are closed.', THEME_TEXTDOMAIN ) ); ?>
            </p>
		<?php
		endif;

	endif; // Check for have_comments().


    $comment_form_args = array(
        'comment_notes_before' => '',
        'title_reply_before'   => '<div id="reply-title" class="comment-reply-title">',
        'title_reply_after'    => '</div>',
    );

    // текст перед кнопкой Отправить
    $comments_text_before_submit = $wpshop_core->get_option( 'comments_text_before_submit' );
    if ( ! empty( $comments_text_before_submit ) ) {
        $comment_form_args['comment_notes_after'] = '<div class="comment-notes-after">'. $comments_text_before_submit .'</div>';
    }

    $comment_form_args = apply_filters( THEME_SLUG . '_comment_form_args', $comment_form_args );
	comment_form( $comment_form_args );
	?>

</div><!-- #comments -->
