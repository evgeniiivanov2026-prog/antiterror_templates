<?php
/**
 * YARPP Template: WPShop YARPP Template
 * Description: WPShop YARPP Template
 * Author: WPShop
 */

global $wpshop_advertising;
?>

<?php if ( have_posts() ) : ?>

<!-- yarpp -->
<div class="related-posts container">

    <?php do_action( THEME_SLUG . '_before_related' ) ?>

    <div class="related-posts__header"><?php echo apply_filters( THEME_SLUG . '_related_title', __( 'Related articles', THEME_TEXTDOMAIN ) ) ?></div>

    <?php echo $wpshop_advertising->show_ad( 'before_related' ) ?>

    <div class="related-posts__list">
        <?php
            while ( have_posts() ) : the_post();
                get_template_part( 'template/content', 'related' );
            endwhile;
        ?>
    </div>

    <?php echo $wpshop_advertising->show_ad( 'after_related' ) ?>

    <?php do_action( THEME_SLUG . '_after_related' ) ?>

</div>

<?php else : ?>
<!-- no YARPP related -->
<?php endif; ?>
