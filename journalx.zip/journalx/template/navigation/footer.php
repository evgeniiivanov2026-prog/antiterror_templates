<?php
/**
 * ****************************************************************************
 *
 *   DON'T EDIT THIS FILE
 *   After update you will lose all changes. Use child theme
 *
 *   НЕ РЕДАКТИРУЙТЕ ЭТОТ ФАЙЛ
 *   После обновления Вы потереяете все изменения. Используйте дочернюю тему
 *
 *   https://support.wpshop.ru/docs/general/child-themes/
 *
 * *****************************************************************************
 *
 * @package journalx
 */

global $wpshop_core;
?>

<?php if ( has_nav_menu( 'footer_menu' ) ) {  ?>
    <div class="footer-navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
        <?php wp_nav_menu( array( 'theme_location' => 'footer_menu', 'menu_class' => 'footer-menu', 'container' => false ) ); ?>
    </div><!--footer-navigation-->
<?php } ?>
