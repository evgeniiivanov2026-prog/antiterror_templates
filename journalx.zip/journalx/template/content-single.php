<?php
/**
 * ****************************************************************************
 *
 *   DON'T EDIT THIS FILE
 *   After update you will lose all changes. Use child theme
 *
 *   НЕ РЕДАКТИРУЙТЕ ЭТОТ ФАЙЛ
 *   После обновления Вы потереяете все изменения. Используйте дочернюю тему
 *
 *   https://support.wpshop.ru/docs/general/child-themes/
 *
 * *****************************************************************************
 *
 * @package journalx
 */

global $wpshop_core;
global $wpshop_template;
global $wpshop_rating;

$structure_single_hide  = $wpshop_core->get_option( 'structure_single_hide' );
if ( ! empty( $structure_single_hide ) ) {
    $structure_single_hide = explode( ',', $structure_single_hide );
    if ( is_array( $structure_single_hide ) ) {
        $structure_single_hide = array_map( 'trim', $structure_single_hide );
    }
} else {
    $structure_single_hide = array();
}

$thumb_url = '';
$thumb_caption = get_the_post_thumbnail_caption( $post );
$post_thumbnail_class = '';

$thumbnail_size    = get_post_meta( $post->ID, 'thumbnail_size', true );
$thumbnail_caption = get_post_meta( $post->ID, 'thumbnail_caption', true );

if ( $thumbnail_size == 'full' ) {
    $thumb_url = get_the_post_thumbnail_url( $post, 'full' );
}

if ( $thumbnail_size == 'wide' ) {
    $post_thumbnail_class = ' post-thumbnail--wide';
}

$is_show_thumb          = ( ! in_array( 'thumbnail', $structure_single_hide ) && $wpshop_core->is_show_element( 'thumbnail' ) );
$is_show_breadcrumbs    = $wpshop_core->is_show_element( 'breadcrumbs' );
$is_show_meta           = $wpshop_core->is_show_element( 'meta' );
$is_show_title_h1       = $wpshop_core->is_show_element( 'title_h1' );
$is_show_excerpt        = ( ! in_array( 'excerpt', $structure_single_hide ) );
$is_show_tags           = ( ! in_array( 'tags', $structure_single_hide ) );
$is_show_rating         = ( ! in_array( 'rating', $structure_single_hide ) && $wpshop_core->is_show_element( 'rating' ) );
$is_show_author_box     = ( ! in_array( 'author_box', $structure_single_hide ) && $wpshop_core->is_show_element( 'author_box' ) );
$is_show_comments       = ( ! in_array( 'comments', $structure_single_hide ) && $wpshop_core->is_show_element( 'comments' ) );
$is_show_social_buttons = ( ! in_array( 'social_buttons', $structure_single_hide ) && $wpshop_core->is_show_element( 'social_buttons' ) );
$is_show_related_posts  = $wpshop_core->is_show_element( 'related_posts' );

$is_replace_ajax_comments = $wpshop_core->get_option( 'comments_output' );

// если загружен пост в подгрузке
$is_scroll_loaded = get_query_var( 'is_scroll_loaded' ) == 'yes';

// проверяем показываем полностью текст или обрезаем
$loaded_content_height = $wpshop_core->get_option( 'loaded_content_height' );
$hide_loaded_content = $loaded_content_height && $is_scroll_loaded;
?>

<article id="post-<?php the_ID(); ?>" data-post-id="<?php the_ID(); ?>" <?php post_class( 'article-wrap js-post-container' ); ?>>
    <?php if ( $is_show_thumb && ! empty( $thumb_url ) ) echo '<div class="entry-header-background" style="background-image: url(' . $thumb_url . ');">'; ?>

	<header class="entry-header">
		<?php
        if ( $thumbnail_size == 'full' && $is_show_breadcrumbs ) {
            get_template_part( 'template/parts/breadcrumbs' );
        }
        ?>

        <?php if ( $is_show_meta ) { ?>
            <div class="entry-meta">
                <?php get_template_part( 'template/parts/entry', 'meta' ) ?>
            </div><!-- .entry-meta -->
        <?php } ?>

        <?php if ( $is_show_title_h1 ) { ?>
            <?php do_action( THEME_SLUG . '_single_before_title' ); ?>
            <h1 class="entry-title" itemprop="headline"><?php the_title() ?></h1>
            <?php do_action( THEME_SLUG . '_single_after_title' ); ?>
        <?php } ?>
	</header><!-- .entry-header -->

    <?php if ( $is_show_thumb && ! empty( $thumb_url ) ) echo '</div>'; ?>

    <?php $thumb = get_the_post_thumbnail( $post->ID, $thumbnail_size, array( 'itemprop'=>'image' ) );
    if ( ! empty( $thumb ) && $is_show_thumb && $thumbnail_size != 'full' && $thumbnail_size != 'no' ) : ?>
    <div class="post-thumbnail<?php echo $post_thumbnail_class ?>">
        <?php echo $thumb;  ?>
    </div><!-- .post-thumbnail -->
    <?php endif; ?>
    <?php if ( ! empty( $thumb ) && $is_show_thumb && $thumbnail_size != 'no' && $thumbnail_caption && ! empty ( $thumb_caption ) ) echo '<figcaption class="entry-image--' . $thumbnail_size . '-caption wp-caption-text" style="margin-bottom: 20px;">' . get_the_post_thumbnail_caption() . '</figcaption>' ?>

    <?php
    $excerpt = get_the_excerpt();
    if ( $is_show_excerpt && has_excerpt() ) {
        do_action( THEME_SLUG . '_single_before_excerpt' );
        echo '<div class="entry-excerpt">' . $excerpt . '</div>';
        do_action( THEME_SLUG . '_single_after_excerpt' );
    }
    ?>

	<div class="entry-content js-entry-content<?php if ( $hide_loaded_content ) echo ' entry-content--hidden' ?>"<?php if ( $hide_loaded_content ) { ?> style="max-height: <?php echo $loaded_content_height + 100 ?>px;" data-content-height="<?php echo $loaded_content_height ?>"<?php } ?> itemprop="articleBody">
		<?php
            do_action( THEME_SLUG . '_single_before_the_content' );
			the_content( sprintf(
				wp_kses(
					/* translators: %s: Name of current post. Only visible to screen readers */
					__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', THEME_TEXTDOMAIN ),
					array(
						'span' => array(
							'class' => array(),
						),
					)
				),
				get_the_title()
			) );
            do_action( THEME_SLUG . '_single_after_the_content' );

			wp_link_pages( array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', THEME_TEXTDOMAIN ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->

    <?php echo do_shortcode( $wpshop_core->get_option( 'code_after_content' ) ) ?>

    <?php
    $post_tags = get_the_tags();

    $source_link = get_post_meta( $post->ID, 'source_link', true );
    $source_hide = get_post_meta( $post->ID, 'source_hide', true );

    if ( $is_show_tags && $post_tags || $source_link ) {
        echo '<div class="entry-tags container">';

        if ( $is_show_tags && $post_tags ) {
            echo '<div class="entry-tag">';
            foreach ( $post_tags as $tag ) {
                echo '<a href="' . get_tag_link( $tag->term_id ) . '">' . $tag->name . '</a> ';
            }
            echo '</div>';
        }

        if ( ! empty( $source_link ) ) {
            echo '<span class="meta-source">';
            if ( $source_hide == 'checked' ) {
                echo '<span class="ps-link js-link" data-href="' . $source_link .'" data-target="_blank" rel="noopener">' . __( 'Source', THEME_TEXTDOMAIN ) . '</span>';
            } else {
                echo '<a href="'. $source_link .'" target="_blank">' . __( 'Source', THEME_TEXTDOMAIN ) . '</a>';
            }
            echo '</span>';
        }
        echo '</div>';
    }
    ?>

    <?php if ( $is_show_rating ) { ?>
        <div class="entry-rating">
            <div class="entry-bottom__header"><?php echo apply_filters( THEME_SLUG . '_rating_title', __( 'Rating', THEME_TEXTDOMAIN ) ) ?></div>
            <?php $post_id = $post ? $post->ID : 0; $wpshop_rating->the_rating( $post_id, apply_filters( THEME_SLUG . '_rating_text_show', true ) ); ?>
        </div>
    <?php } ?>

    <?php if ( $is_show_author_box ) get_template_part( 'template/parts/author', 'box' ); ?>

    <?php if ( $is_show_comments || $is_show_social_buttons ) : ?>
    <footer class="entry-footer">
        <?php if ( comments_open() && $is_show_comments && ! $is_replace_ajax_comments ) { ?>
            <span class="entry-footer__comments js-load-comments" data-post-id="<?php echo $post->ID ?>"><?php echo apply_filters( THEME_SLUG . '_comments_title', __( 'Comments', THEME_TEXTDOMAIN ) ) ?><sup><?php echo get_comments_number() ?></sup></span>
        <?php } ?>

        <?php if ( $is_show_social_buttons ) { ?>
            <?php if ( apply_filters( THEME_SLUG . '_social_share_title_show', true ) ) : ?>
                <span class="entry-footer__share-title"><?php echo apply_filters( THEME_SLUG . '_social_share_title', __( 'Share:', THEME_TEXTDOMAIN ) ) ?> </span>
            <?php endif; ?>

		    <?php get_template_part( 'template/parts/social', 'buttons' ) ?>
        <?php } ?>
	</footer><!-- .entry-footer -->
    <?php endif; ?>

    <?php if ( ! $is_replace_ajax_comments ) { ?>

        <?php if ( comments_open() ) : ?>
        <div id="entry_comments_<?php echo $post->ID ?>" class="entry-comments" data-post-id="<?php echo $post->ID ?>">
            <div class="donut"></div>  <?php _e( 'Loading...', THEME_TEXTDOMAIN ); ?>
        </div>
        <?php endif; ?>

    <?php } else { ?>

        <?php if ( comments_open() && $is_show_comments ) : ?>
            <div id="entry_comments_<?php echo $post->ID ?>" class="entry-comments" data-post-id="<?php echo $post->ID ?>" style="display: block;">
                <?php if ( get_comments_number() > 0 ) { ?>
                    <div class="comments-title"><?php echo apply_filters( THEME_SLUG . '_comments_title', __( 'Comments', THEME_TEXTDOMAIN ) ) ?><sup><?php echo get_comments_number() ?></sup></div>
                <?php } ?>
                <?php comments_template(); ?>
            </div>
        <?php endif; ?>

    <?php } ?>

    <?php if ( $is_show_related_posts ) { ?>
        <?php do_action( THEME_SLUG . '_single_before_related' ); ?>
        <?php get_template_part( 'template/parts/related', 'posts' ) ?>
        <?php do_action( THEME_SLUG . '_single_after_related' ); ?>
    <?php } ?>

</article><!-- #post-<?php the_ID(); ?> -->

<?php if ( ! empty( $thumb ) && $is_show_thumb && $thumbnail_size == 'full' && $thumbnail_size != 'no' ) { ?>
    <meta itemprop="image" content="<?php echo $thumb_url ?>">
<?php } ?>
<meta itemscope itemprop="mainEntityOfPage" itemType="https://schema.org/WebPage" itemid="<?php the_permalink() ?>" content="<?php the_title(); ?>">
<meta itemprop="dateModified" content="<?php the_modified_time( 'Y-m-d' )?>">
<meta itemprop="datePublished" content="<?php the_time( 'c' ) ?>">
<meta itemprop="author" content="<?php echo get_the_author() ?>">
<?php echo $wpshop_template->get_microdata_publisher() ?>