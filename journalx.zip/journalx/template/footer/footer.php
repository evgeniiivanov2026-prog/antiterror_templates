<?php
/**
 * ****************************************************************************
 *
 *   DON'T EDIT THIS FILE
 *   After update you will lose all changes. Use child theme
 *
 *   НЕ РЕДАКТИРУЙТЕ ЭТОТ ФАЙЛ
 *   После обновления Вы потереяете все изменения. Используйте дочернюю тему
 *
 *   https://support.wpshop.ru/docs/general/child-themes/
 *
 * *****************************************************************************
 *
 * @package journalx
 */

global $wpshop_core;
global $wpshop_partner;

$is_show_footer = $wpshop_core->is_show_element( 'footer' );

$footer_html_block_1 = $wpshop_core->get_option( 'footer_html_block_1' );
$footer_html_block_2 = $wpshop_core->get_option( 'footer_html_block_2' );
$footer_counters     = $wpshop_core->get_option( 'footer_counters' );

?>


    <?php do_action( THEME_SLUG . '_before_footer' ); ?>

    <?php if ( $is_show_footer ) { ?>

        <footer id="colophon" class="site-footer" itemscope itemtype="http://schema.org/WPFooter">
            <div class="site-footer-inner <?php $wpshop_core->the_option( 'footer_width' ) ?>">

                <div class="footer-info">
                    <?php
                    $footer_copyright = $wpshop_core->get_option( 'footer_copyright' );
                    $footer_copyright = str_replace( '%year%', date( 'Y' ), $footer_copyright );
                    echo $footer_copyright;
                    ?>

                    <?php if ( 'yes' == $wpshop_core->get_option( 'wpshop_partner_enable' ) ) : ?>
                        <!--noindex-->
                        <div class="footer-partner">
                            <?php
                            $wpshop_partner->the_link( [
                                'prefix'     => $wpshop_core->get_option( 'wpshop_partner_prefix' ),
                                'postfix'    => $wpshop_core->get_option( 'wpshop_partner_postfix' ),
                                'partner_id' => ( defined( 'WPSHOP_PARTNER' ) ) ? WPSHOP_PARTNER : 0,
                            ] );
                            ?>
                        </div>
                        <!--/noindex-->
                    <?php endif; ?>
                </div>

                <?php if ( ! empty( $footer_html_block_1 ) ) : ?>
                    <div class="footer-html-1">
                        <?php echo do_shortcode( $footer_html_block_1 ); ?>
                    </div>
                <?php endif; ?>

                <?php if ( $wpshop_core->get_option( 'footer_social' ) ) {
                    get_template_part( 'template/parts/social', 'links' );
                } ?>

                <?php get_template_part( 'template/navigation/footer' ); ?>

                <?php if ( ! empty( $footer_html_block_2 ) ) : ?>
                    <div class="footer-html-2">
                        <?php echo do_shortcode( $footer_html_block_2 ); ?>
                    </div>
                <?php endif; ?>

                <?php if ( ! empty( $footer_counters ) ) : ?>
                    <div class="footer-counters">
                        <?php echo $footer_counters; ?>
                    </div>
                <?php endif; ?>

            </div>
        </footer><!-- #colophon -->

    <?php } ?>

    <?php do_action( THEME_SLUG . '_after_footer' ); ?>