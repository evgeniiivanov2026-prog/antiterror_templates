<?php
/**
 * ****************************************************************************
 *
 *   DON'T EDIT THIS FILE
 *   After update you will lose all changes. Use child theme
 *
 *   НЕ РЕДАКТИРУЙТЕ ЭТОТ ФАЙЛ
 *   После обновления Вы потереяете все изменения. Используйте дочернюю тему
 *
 *   https://support.wpshop.ru/docs/general/child-themes/
 *
 * *****************************************************************************
 *
 * @package journalx
 */

global $wpshop_core;
global $wpshop_template;
global $wpshop_rating;

$structure_page_hide  = $wpshop_core->get_option( 'structure_page_hide' );
if ( ! empty( $structure_page_hide ) ) {
    $structure_page_hide = explode( ',', $structure_page_hide );
} else {
    $structure_page_hide = array();
}

$thumb_url = '';
$post_thumbnail_class = '';
$thumbnail_size = get_post_meta( $post->ID, 'thumbnail_size', true );

if ( $thumbnail_size == 'full' ) {
    $thumb_url = get_the_post_thumbnail_url( $post, 'full' );
}

if ( $thumbnail_size == 'wide' ) {
    $post_thumbnail_class = ' post-thumbnail--wide';
}

$is_show_thumb          = ( ! in_array( 'thumbnail', $structure_page_hide ) && $wpshop_core->is_show_element( 'thumbnail' ) );
$is_show_breadcrumbs    = $wpshop_core->is_show_element( 'breadcrumbs' );
$is_show_title_h1       = $wpshop_core->is_show_element( 'title_h1' );
$is_show_rating         = ( ! in_array( 'rating', $structure_page_hide ) && $wpshop_core->is_show_element( 'rating' ) );
$is_show_comments       = ( ! in_array( 'comments', $structure_page_hide ) && $wpshop_core->is_show_element( 'comments' ) );
$is_show_social_buttons = ( ! in_array( 'social_buttons', $structure_page_hide ) && $wpshop_core->is_show_element( 'social_buttons' ) );
$is_show_related_posts  = $wpshop_core->is_show_element( 'related_posts' );

$is_replace_ajax_comments = $wpshop_core->get_option( 'comments_output' );
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

    <?php if ( $is_show_thumb && ! empty( $thumb_url ) ) echo '<div class="entry-header-background" style="background-image: url(' . $thumb_url . ');">'; ?>

    <header class="entry-header">
        <?php
        if ( $thumbnail_size == 'full' && $is_show_breadcrumbs ) {
            get_template_part( 'template/parts/breadcrumbs' );
        }
        ?>

        <?php if ( $is_show_title_h1 ) { ?>
            <?php do_action( THEME_SLUG . '_page_before_title' ) ?>
            <h1 class="entry-title" itemprop="headline"><?php the_title() ?></h1>
            <?php do_action( THEME_SLUG . '_page_after_title' ) ?>
        <?php } ?>
	</header><!-- .entry-header -->

    <?php if ( $is_show_thumb && ! empty( $thumb_url ) ) echo '</div>'; ?>

    <?php $thumb = get_the_post_thumbnail( $post->ID, $thumbnail_size, array( 'itemprop'=>'image' ) );
    if ( ! empty( $thumb ) && $is_show_thumb && $thumbnail_size != 'full' && $thumbnail_size != 'no' ) : ?>
        <div class="post-thumbnail<?php echo $post_thumbnail_class ?>">
            <?php echo $thumb; ?>
        </div><!-- .post-thumbnail -->
    <?php endif; ?>

	<div class="entry-content" itemprop="articleBody">
		<?php
            do_action( THEME_SLUG . '_page_before_the_content' );
			the_content();
            do_action( THEME_SLUG . '_page_after_the_content' );

			wp_link_pages( array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', THEME_TEXTDOMAIN ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->

    <?php if ( $is_show_rating ) { ?>
        <div class="entry-rating">
            <div class="entry-bottom__header"><?php echo apply_filters( THEME_SLUG . '_rating_title', __( 'Rating', THEME_TEXTDOMAIN ) ) ?></div>
            <?php $post_id = $post ? $post->ID : 0; $wpshop_rating->the_rating( $post_id, apply_filters( THEME_SLUG . '_rating_text_show', true ) ); ?>
        </div>
    <?php } ?>

    <?php if ( $is_show_comments || $is_show_social_buttons ) : ?>
    <footer class="entry-footer">
        <?php if ( comments_open() && $is_show_comments && ! $is_replace_ajax_comments ) { ?>
            <span class="entry-footer__comments js-load-comments" data-post-id="<?php echo $post->ID ?>"><?php _e( 'Comments', THEME_TEXTDOMAIN ) ?><sup><?php echo get_comments_number() ?></sup></span>
        <?php } ?>

        <?php if ( $is_show_social_buttons ) { ?>
            <?php if ( apply_filters( THEME_SLUG . '_social_share_title_show', true ) ) : ?>
                <span class="entry-footer__share-title"><?php echo apply_filters( THEME_SLUG . '_social_share_title', __( 'Share:', THEME_TEXTDOMAIN ) ) ?> </span>
            <?php endif; ?>

            <?php get_template_part( 'template/parts/social', 'buttons' ) ?>
        <?php } ?>
    </footer><!-- .entry-footer -->
    <?php endif; ?>

    <?php if ( ! $is_replace_ajax_comments ) { ?>

        <?php if ( comments_open() ) : ?>
            <div id="entry_comments_<?php echo $post->ID ?>" class="entry-comments">
                <div class="donut"></div>  <?php _e( 'Loading...', THEME_TEXTDOMAIN ); ?>
            </div>
        <?php endif; ?>

    <?php } else { ?>

        <?php if ( comments_open() && $is_show_comments ) : ?>
            <div class="comments-bottom">
                <?php if ( get_comments_number() > 0 ) { ?>
                    <div class="comments-title"><?php _e( 'Comments', THEME_TEXTDOMAIN ) ?><sup><?php echo get_comments_number() ?></sup></div>
                <?php } ?>
                <?php comments_template(); ?>
            </div>
        <?php endif; ?>

    <?php } ?>

    <meta itemscope itemprop="mainEntityOfPage" itemType="https://schema.org/WebPage" itemid="<?php the_permalink() ?>" content="<?php the_title(); ?>">
    <meta itemprop="dateModified" content="<?php the_modified_time( 'Y-m-d' )?>">
    <meta itemprop="datePublished" content="<?php the_time( 'c' ) ?>">
    <meta itemprop="author" content="<?php the_author() ?>">
    <?php echo $wpshop_template->get_microdata_publisher() ?>

    <?php
    if ( $is_show_related_posts ) {
        do_action( THEME_SLUG . '_page_before_related' );
        get_template_part( 'template/parts/related', 'posts' );
        do_action( THEME_SLUG . '_page_after_related' );
    }
    ?>

</article><!-- #post-<?php the_ID(); ?> -->