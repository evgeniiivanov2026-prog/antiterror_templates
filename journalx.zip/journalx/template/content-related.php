<?php
/**
 * ****************************************************************************
 *
 *   DON'T EDIT THIS FILE
 *   After update you will lose all changes. Use child theme
 *
 *   НЕ РЕДАКТИРУЙТЕ ЭТОТ ФАЙЛ
 *   После обновления Вы потереяете все изменения. Используйте дочернюю тему
 *
 *   https://support.wpshop.ru/docs/general/child-themes/
 *
 * *****************************************************************************
 *
 * @package journalx
 */

global $wpshop_core;
global $wpshop_helper;
global $wpshop_template;

$post_card_type = 'related';
$tag = $wpshop_core->get_option( 'structure_posts_related_tag' );
$article_tag = ( $tag == 'div' ) ? 'div' : 'article';
$post_card_thumb_size = apply_filters( THEME_SLUG . '_post_card_' . $post_card_type . '_thumbnail_size', 'thumb-small' );
$section_options = ( isset( $section_options ) ) ? $section_options : [];


/**
 * order
 */
$post_card_order = $wpshop_core->get_option( 'post_card_' . $post_card_type . '_order' );
$post_card_order = explode( ',', $post_card_order );

$post_card_order_meta = $wpshop_core->get_option( 'post_card_' . $post_card_type . '_order_meta' );
$post_card_order_meta = explode( ',', $post_card_order_meta );


/**
 * post card class
 */
$post_card = new \Wpshop\PostCard\PostCard();
$post_card->set_order( array_merge( $post_card_order, $post_card_order_meta ) );
$post_card->set_section_options( $section_options );


/**
 * default
 */
$post_card_classes  = '';
$description_length = (int) $wpshop_core->get_option( 'post_card_' . $post_card_type . '_excerpt_length' );


/**
 * prepare data
 */
$thumb = get_the_post_thumbnail( $post->ID, $post_card_thumb_size );
if ( empty( $thumb ) || ! $post_card->is_show_element( 'thumbnail' ) ) {
    $post_card_classes = 'post-box--no-thumb';
}

?>

<<?php echo $article_tag ?> class="post-box <?php echo $post_card_classes ?>">

    <a href="<?php the_permalink(); ?>">
        <?php
        foreach ( $post_card_order as $order ) {

            if ( ! empty( $thumb ) && $order == 'thumbnail' && $post_card->is_show_element( 'thumbnail' ) ) :
                echo '<div class="post-box__thumbnail">';
                echo $thumb;
                echo '</div>';
            endif;

            if ( $order == 'title' && $post_card->is_show_element( 'title' ) ) {
                echo '<' . $tag . ' class="post-box__title">';
                echo get_the_title();
                echo '</' . $tag . '>';
            }

            if ( $order == 'excerpt' && $post_card->is_show_element( 'excerpt' ) ) {
                echo '<div class="post-box__description">';
                $excerpt = get_the_excerpt();
                if ( apply_filters( THEME_SLUG . '_post_card_' . $post_card_type . '_excerpt_strip_tags', true ) ) {
                    $excerpt = strip_tags( $excerpt );
                }
                echo $wpshop_helper->substring_by_word( $excerpt, $description_length );
                echo '</div>';
            }

            if ( $order == 'meta' && $post_card->is_show_element( 'meta' ) ) {
                if ( $post_card->is_show_element( 'comments_number' ) || $post_card->is_show_element( 'views' ) ) {
                    echo '<div class="post-box__meta">';

                    foreach ( $post_card_order_meta as $meta_order ) {

                        if ( $meta_order == 'comments_number' && $post_card->is_show_element( 'comments_number' ) ) {
                            echo '<span class="post-box__comments">' . get_comments_number() . '</span>';
                        }

                        if ( $meta_order == 'views' && $post_card->is_show_element( 'views' ) ) {
                            echo '<span class="post-box__views">';
                            echo $wpshop_helper->rounded_number( $wpshop_template->get_views() );
                            echo '</span>';
                        }

                    }

                    echo '</div>';
                }
            }

            if ( $order == 'rating' && $post_card->is_show_element( 'rating' ) ) {
                echo '<div class="post-box__rating">';
                global $wpshop_rating;
                $post_id = $post ? $post->ID : 0; $wpshop_rating->get_the_rating( $post_id );
                echo '</div>';
            }

         }
         ?>
    </a>

</<?php echo $article_tag ?>>
