<?php
/**
 * ****************************************************************************
 *
 *   DON'T EDIT THIS FILE
 *   After update you will lose all changes. Use child theme
 *
 *   НЕ РЕДАКТИРУЙТЕ ЭТОТ ФАЙЛ
 *   После обновления Вы потереяете все изменения. Используйте дочернюю тему
 *
 *   https://support.wpshop.ru/docs/general/child-themes/
 *
 * *****************************************************************************
 *
 * @package journalx
 */

global $post;
global $wpshop_core;
global $wpshop_helper;
global $wpshop_template;

$post_card_type = 'main';
$tag = $wpshop_core->get_option( 'structure_posts_tag' );
$article_tag = ( $tag == 'div' ) ? 'div' : 'article';
$thumb_size = 'thumb-wide';
$post_card_size = get_post_meta( $post->ID, 'post_card_size', true );
$section_options = ( isset( $section_options ) ) ? $section_options : [];

if ( 'wide' == $post_card_size ) {
    $thumb_size = 'thumb-big';
} else if ( 'high' == $post_card_size ) {
    $thumb_size = 'full';
} else if ( 'big' == $post_card_size ) {
    $thumb_size = 'full';
}


/**
 * order
 */
$post_card_order = $wpshop_core->get_option( 'post_card_' . $post_card_type . '_order' );
$post_card_order = explode( ',', $post_card_order );

$post_card_order_meta = $wpshop_core->get_option( 'post_card_' . $post_card_type . '_order_meta' );
$post_card_order_meta = explode( ',', $post_card_order_meta );


/**
 * post card class
 */
$post_card = new \Wpshop\PostCard\PostCard();
$post_card->set_order( array_merge( $post_card_order, $post_card_order_meta ) );
$post_card->set_section_options( $section_options );


/**
 * default
 */
$post_card_attributes = [ 'itemscope', 'itemtype="http://schema.org/BlogPosting"'  ];
$post_card_classes    = [ 'post-box--' . $post_card_size ];
$description_length   = (int) $wpshop_core->get_option( 'post_card_' . $post_card_type . '_excerpt_length' );


/**
 * prepare data
 */
$thumb = get_the_post_thumbnail( $post->ID, $thumb_size, array( 'itemprop' => 'image' ) );
if ( empty( $thumb ) ) {
    $post_card_classes[] = 'post-box--no-thumb';
}
if ( ! $post_card->is_show_element( 'thumbnail' ) ) {
    $post_card_classes[] = 'post-box--no-thumb';
}

?>

<<?php echo $article_tag ?> id="post-<?php the_ID(); ?>" class="post-box <?php echo implode( ' ', $post_card_classes ) ?>" <?php echo implode( ' ', $post_card_attributes ) ?>>

    <a href="<?php the_permalink(); ?>">
        <?php if ( ! empty( $thumb ) && $post_card->is_show_element( 'thumbnail' ) ) :
            echo '<div class="post-box__thumbnail">';
                echo $thumb;
            echo '</div>';
        endif; ?>

        <div class="post-box__body">

            <?php
            foreach ( $post_card_order as $order ) {

                if ( 'post' === get_post_type() && $order == 'category' && $post_card->is_show_element( 'category' ) ) :
                    echo '<div class="post-box__category">';
                    echo $wpshop_template->get_category( array( 'link' => false ) );
                    echo '</div>';
                endif;

                if ( $order == 'title' && $post_card->is_show_element( 'title' ) ) {
                    echo '<' . $tag . ' class="post-box__title" itemprop="headline">';
                    echo get_the_title();
                    echo '</' . $tag . '>';
                }

                if ( $order == 'meta' && $post_card->is_show_element( 'meta' ) ) {
                    if ( $post_card->is_show_element( 'date' ) || $post_card->is_show_element( 'author' ) || $post_card->is_show_element( 'comments_number' ) || $post_card->is_show_element( 'views' ) ) {
                        echo '<div class="post-box__meta">';

                        foreach ( $post_card_order_meta as $meta_order ) {

                            if ( $meta_order == 'date' && $post_card->is_show_element( 'date' ) ) {
                                echo '<span class="post-box__date">';
                                echo '<time itemprop="datePublished" datetime="' . get_the_time( 'Y-m-d' ) . '">';
                                echo get_the_date();
                                echo '</time>';
                                echo '</span>';
                            }

                            if ( $meta_order == 'author' && $post_card->is_show_element( 'author' ) ) {
                                echo '<span class="post-box__author" itemprop="author">';
                                echo get_the_author();
                                echo '</span>';
                            }

                            if ( $meta_order == 'comments_number' && $post_card->is_show_element( 'comments_number' ) ) {
                                echo '<span class="post-box__comments">' . get_comments_number() . '</span>';
                            }

                            if ( $meta_order == 'views' && $post_card->is_show_element( 'views' ) ) {
                                echo '<span class="post-box__views">';
                                echo $wpshop_helper->rounded_number( $wpshop_template->get_views() );
                                echo '</span>';
                            }

                        }

                        echo '</div>';
                    }
                }

                if ( $order == 'excerpt' && $post_card->is_show_element( 'excerpt' ) ) {
                    echo '<div class="post-box__description" itemprop="articleBody">';
                    $excerpt = get_the_excerpt();
                    if ( apply_filters( THEME_SLUG . '_post_card_' . $post_card_type . '_excerpt_strip_tags', true ) ) {
                        $excerpt = strip_tags( $excerpt );
                    }
                    echo $wpshop_helper->substring_by_word( $excerpt, $description_length );
                    echo '</div>';
                }

                if ( $order == 'rating' && $post_card->is_show_element( 'rating' ) ) {
                    echo '<div class="post-box__rating">';
                    global $wpshop_rating;
                    $post_id = $post ? $post->ID : 0; $wpshop_rating->get_the_rating( $post_id );
                    echo '</div>';
                }

            }

        echo '</div>';

    echo '</a>';
    ?>

    <meta itemprop="articleBody" content="<?php echo esc_attr( get_the_excerpt() ) ?>">
    <meta itemprop="author" content="<?php echo esc_attr( get_the_author() ) ?>">
    <meta itemscope itemprop="mainEntityOfPage" itemType="https://schema.org/WebPage" itemid="<?php echo esc_attr( get_the_permalink() ) ?>" content="<?php echo esc_attr( get_the_title() ) ?>">
    <meta itemprop="dateModified" content="<?php echo esc_attr( get_the_modified_time( 'Y-m-d' ) ) ?>">
    <meta itemprop="datePublished" content="<?php echo esc_attr( get_the_time( 'c' ) ) ?>">
    <?php echo $wpshop_template->get_microdata_publisher() ?>

</<?php echo $article_tag ?>><!-- #post-<?php the_ID(); ?> -->
