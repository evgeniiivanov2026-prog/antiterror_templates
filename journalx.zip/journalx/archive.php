<?php
/**
 * ****************************************************************************
 *
 *   DON'T EDIT THIS FILE
 *   After update you will lose all changes. Use child theme
 *
 *   НЕ РЕДАКТИРУЙТЕ ЭТОТ ФАЙЛ
 *   После обновления Вы потереяете все изменения. Используйте дочернюю тему
 *
 *   https://support.wpshop.ru/docs/general/child-themes/
 *
 * *****************************************************************************
 *
 * @package journalx
 */

global $wpshop_core;

$is_show_breadcrumbs      = $wpshop_core->get_option( 'breadcrumbs_archive' );
$is_show_description_show = $wpshop_core->get_option( 'structure_archive_description_show' );

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

            <?php if ( $is_show_breadcrumbs ) {
                get_template_part( 'template/parts/breadcrumbs' );
            } ?>

		    <?php if ( have_posts() ) : ?>

			    <header class="page-header">
				    <?php do_action( THEME_SLUG . '_archive_before_title' ); ?>
                    <?php the_archive_title( '<h1 class="page-title">', '</h1>' ); ?>
                    <?php do_action( THEME_SLUG . '_archive_after_title' ); ?>
                </header><!-- .page-header -->

                <?php if ( is_category() && $wpshop_core->get_option( 'structure_archive_subcategories' ) == 'yes' ) {
                    $cat = get_query_var('cat');

                    $categories = get_categories( array(
                        'parent' => $cat
                    ) );

                    if ( ! empty( $categories ) ) {
                        echo '<div class="child-categories"><ul>';
                        foreach ( $categories as $category ) {
                            echo '<li>';
                            echo '<a href="' . get_term_link( $category->term_id ) . '">' . $category->name . '</a>';
                            echo '</li>';
                        }
                        echo '</ul></div>';
                    }
                } ?>

                <?php if ( $is_show_description_show && 'top' == $wpshop_core->get_option( 'structure_archive_description' ) && ! is_paged() ) the_archive_description( '<div class="archive-description">', '</div>' ); ?>

			    <?php

                echo '<div class="post-boxes">';

			    while ( have_posts() ) : the_post();

			        do_action( THEME_SLUG . '_archive_before_posts' );
				    get_template_part( 'template/content', get_post_format() );
                    do_action( THEME_SLUG . '_archive_after_posts' );

			    endwhile;

                echo '</div>';

                echo '<div class="pagination-box js-pagination-box">';
                if ( 1 == 1 ) {
                    $class_scroll = new Scroll();
                    $class_scroll->infinity_scroll_holder();
                }
                the_posts_pagination();
                echo '</div><!--.pagination-box-->'; ?>

                <?php if ( $is_show_description_show && 'bottom' == $wpshop_core->get_option( 'structure_archive_description' ) && ! is_paged() ) the_archive_description( '<div class="archive-description">', '</div>' ); ?>

            <?php else : ?>

			    <?php get_template_part( 'template/content', 'none' ); ?>

		    <?php endif; ?>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();
