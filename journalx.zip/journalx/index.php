<?php
/**
 * ****************************************************************************
 *
 *   DON'T EDIT THIS FILE
 *   After update you will lose all changes. Use child theme
 *
 *   НЕ РЕДАКТИРУЙТЕ ЭТОТ ФАЙЛ
 *   После обновления Вы потереяете все изменения. Используйте дочернюю тему
 *
 *   https://support.wpshop.ru/docs/general/child-themes/
 *
 * *****************************************************************************
 *
 * @package journalx
 */

global $wpshop_core;

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

		    <?php if ( have_posts() ) : ?>

                <?php if ( is_home() && ! is_front_page() ) :
                    echo '<h1 class="page-title screen-reader-text">' . single_post_title( '', false ) . '</h1>';
                endif; ?>

                <?php if ( 'top' == $wpshop_core->get_option( 'structure_home_position' ) ) get_template_part( 'template/home', 'content' ); ?>

                <?php echo '<div class="post-boxes">'; ?>

			    <?php while ( have_posts() ) : the_post(); ?>

				    <?php get_template_part( 'template/content', get_post_format() ); ?>

			    <?php endwhile; ?>

			    <?php echo '</div><!--.post-boxes-->';

			    echo '<div class="pagination-box js-pagination-box">';
                    if ( 1 == 1 ) {
                        $class_scroll = new Scroll();
                        $class_scroll->infinity_scroll_holder();
                    }
                    the_posts_pagination();
                echo '</div><!--.pagination-box-->'; ?>

                <?php if ( 'bottom' == $wpshop_core->get_option( 'structure_home_position' ) ) get_template_part( 'template/home', 'content' ); ?>

            <?php else : ?>

			    <?php get_template_part( 'template/content', 'none' ); ?>

		    <?php endif; ?>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();
