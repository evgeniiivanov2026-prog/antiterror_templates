<?php
/**
 * ****************************************************************************
 *
 *   DON'T EDIT THIS FILE
 *   After update you will lose all changes. Use child theme
 *
 *   НЕ РЕДАКТИРУЙТЕ ЭТОТ ФАЙЛ
 *   После обновления Вы потереяете все изменения. Используйте дочернюю тему
 *
 *   https://support.wpshop.ru/docs/general/child-themes/
 *
 * *****************************************************************************
 *
 * @package journalx
 */

global $wpshop_core;
global $wpshop_advertising;

$is_show_arrow       = $wpshop_core->get_option( 'structure_arrow' );
$structure_arrow_mob = ( $wpshop_core->get_option( 'structure_arrow_mob' ) ) ? ' data-mob="on"' : '';

?>

	</div><!-- #content -->

    <?php do_action( THEME_SLUG . '_after_site_content' ); ?>

    <?php echo $wpshop_advertising->show_ad( 'after_site_content' ); ?>

    <?php get_template_part( 'template/footer/footer' ) ?>

    <?php if ( $is_show_arrow ) { ?>
        <button type="button" class="scrolltop js-scrolltop"<?php echo $structure_arrow_mob ?>></button>
    <?php } ?>

</div><!-- #page -->

<?php wp_footer(); ?>
<?php $wpshop_core->the_option( 'code_body' ) ?>

</body>
</html>