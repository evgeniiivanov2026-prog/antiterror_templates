<?php

class JournalX_Comments {

    public function __construct() {
    }

    public function hooks() {
        add_action( 'wp_ajax_nopriv_ajax_load_comments', array( $this, 'load_comments_handler' ) );
        add_action( 'wp_ajax_ajax_load_comments', array( $this, 'load_comments_handler' ) );
    }

    public function load_comments_handler() {

        $nonce = $_POST['nonce'];

        // проверяем nonce код, если проверка не пройдена прерываем обработку
        if ( ! wp_verify_nonce( $nonce, 'wpshop-nonce' ) ) {
            die( 'Stop!' );
        }

        $post_id = (int) $_POST['post_id'];

        global $wp_query;

        if ( ! empty( $_POST['spage'] ) ) {
            $wp_query->set( 'spage', $_POST['spage'] );
        }


        $wp_query = new WP_Query( array(
            'post_type' => array( 'post', 'page' ),
            'p' => $post_id
        ) );
        while ( $wp_query->have_posts() ) : $wp_query->the_post();
            if ( ! empty( $_POST['cpage'] ) ) {
                $wp_query->set( 'cpage', $_POST['cpage'] );
            }
            global $withcomments;
            $withcomments = true;
            comments_template();
        endwhile;

        wp_die();

    }

    public function the_comments_pagination( $args = array() ) {
        if ( ! is_singular() )
            return;

        $page = get_query_var( 'cpage' );
        if ( ! $page )
            $page = 1;
        $max_page = get_comment_pages_count();
        $defaults = array(
            'base'         => add_query_arg( 'cpage', '%#%' ),
            'format'       => '',
            'total'        => $max_page,
            'current'      => $page,
            'echo'         => true,
            'add_fragment' => ''
        );

        $defaults['base'] = trailingslashit( get_permalink() ) . '#commentpage-%#%';

        $args = wp_parse_args( $args, $defaults );
        $page_links = paginate_links( $args );

        if ( $page_links ) {
            $navigation = _navigation_markup( $page_links, 'comments-pagination', $args['screen_reader_text'] );
            echo $navigation;
        }

    }

}
$class_journalx_comments = new JournalX_Comments();
$class_journalx_comments->hooks();