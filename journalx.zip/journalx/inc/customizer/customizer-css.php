<?php

use Wpshop\Core\Customizer\CustomizerCSS;

function wpshop_customizer_css() {
    global $default_options;
    global $wpshop_core;

    $class_customizer_css = new CustomizerCSS( [ 'defaults' => $default_options, 'theme_slug' => THEME_SLUG ] );

    //  layout  >  header
    $class_customizer_css->add(
        '.site-header',
        [ 'padding-top:%dpx', 'header_padding_top' ],
        '(min-width: 768px)'
    );

    $class_customizer_css->add(
        '.site-header',
        [ 'padding-bottom:%dpx', 'header_padding_bottom' ],
        '(min-width: 768px)'
    );


    // blocks  >  header
    $class_customizer_css->add(
        '.site-logotype',
        [ 'max-width:%dpx', 'logotype_max_width' ]
    );

    $class_customizer_css->add(
        '.site-logotype img',
        [ 'max-height:%dpx', 'logotype_max_height' ]
    );


    // modules  >  scroll to top
    $class_customizer_css->add(
        '.scrolltop',
        [ 'background-color:%s', 'structure_arrow_bg' ]
    );

    $class_customizer_css->add(
        '.scrolltop:before',
        [ 'color:%s', 'structure_arrow_color' ]
    );

    $class_customizer_css->add(
        '.scrolltop',
        [ 'width:%dpx', 'structure_arrow_width' ]
    );

    $class_customizer_css->add(
        '.scrolltop',
        [ 'height:%dpx', 'structure_arrow_height' ]
    );

    if ( $wpshop_core->get_option( 'structure_arrow_position' ) == 'left' ) {
        $class_customizer_css->add(
            '.scrolltop',
            [ 'left: 10px', '' ]
        );
    }

    $class_customizer_css->add(
        '.scrolltop:before',
        [ 'content:"%s"', 'structure_arrow_icon' ]
    );


    // typography  >  general
    $class_customizer_css->add(
        'body, .archive-description, .entry-content, .home-text',
        [ 'typography', 'typography_body' ]
    );


    // typography  >  header
    $class_customizer_css->add(
        '.site-title, .site-title a',
        [ 'typography', 'typography_site_title' ]
    );

    $class_customizer_css->add(
        '.site-description',
        [ 'typography', 'typography_site_description' ]
    );


    // typography  >  menu
    $class_customizer_css->add(
        '.main-navigation ul li a, .main-navigation ul li span, .footer-navigation ul li a, .footer-navigation ul li span',
        [ 'typography', 'typography_menu_links' ]
    );


    // typography > headers
    $class_customizer_css->add(
        '.h1, h1:not(.site-title)',
        [ 'typography', 'typography_header_h1' ]
    );

    $class_customizer_css->add(
        '.h2, .related-posts__header, .section-block__title, h2',
        [ 'typography', 'typography_header_h2' ]
    );

    $class_customizer_css->add(
        '.h3, h3',
        [ 'typography', 'typography_header_h3' ]
    );

    $class_customizer_css->add(
        '.h4, h4',
        [ 'typography', 'typography_header_h4' ]
    );

    $class_customizer_css->add(
        '.h5, h5',
        [ 'typography', 'typography_header_h5' ]
    );

    $class_customizer_css->add(
        '.h6, h6',
        [ 'typography', 'typography_header_h6' ]
    );


    // tweak disable footer sticky
    if ( $wpshop_core->get_option( 'footer_sticky_disable' ) ) {
        $class_customizer_css->add(
            'body',
            [ 'margin-bottom: 0', '' ]
        );
    }


    // colors
    $class_customizer_css->add(
        '.page-separator, .pagination .current, .pagination a.page-numbers:hover, .entry-content ul:not([class])>li:before, .entry-content ul.wp-block-list>li:before, .btn, .btn-primary:hover, .btn-primary:not(:disabled):not(.disabled).active, .btn-primary:not(:disabled):not(.disabled):active, .show>.btn-primary.dropdown-toggle, .comment-respond .form-submit input, .page-links__item',
        [ 'background-color:%s', 'color_main' ]
    );
    $class_customizer_css->add(
        '.post-box--big .post-box__category span, .post-box--high .post-box__category span, .post-box--wide .post-box__category span, .entry-content ul:not([class])>li:before, .entry-content ul.wp-block-list>li:before, .home-text ul:not([class])>li:before, .home-text ul.wp-block-list>li:before, .page-content ul:not([class])>li:before, .page-content ul.wp-block-list>li:before, .archive-description ul:not([class])>li:before, .archive-description ul.wp-block-list>li:before',
        [ 'background-color:%s', 'color_main' ]
    );

    $class_customizer_css->add(
        '.spoiler-box, .entry-content ol:not([class])>li:before, .entry-content ol.wp-block-list>li:before, .home-text ol:not([class])>li:before, .home-text ol.wp-block-list>li:before, .page-content ol:not([class])>li:before, .page-content ol.wp-block-list>li:before, .archive-description ol:not([class])>li:before, .archive-description ol.wp-block-list>li:before, .btn-primary, .btn-primary:hover, .btn-primary:not(:disabled):not(.disabled).active, .btn-primary:not(:disabled):not(.disabled):active, .show>.btn-primary.dropdown-toggle, .inp:focus, .entry-tag a:focus, .entry-tag a:hover, .search-screen .search-form .search-field:focus, .entry-content blockquote:not(.wpremark),
        .input:focus, input[type=email]:focus, input[type=number]:focus, input[type=password]:focus, input[type=search]:focus, input[type=tel]:focus, input[type=text]:focus, input[type=url]:focus, select:focus, textarea:focus',
        [ 'border-color:%s !important', 'color_main' ]
    );

    $class_customizer_css->add(
        '.entry-content blockquote:before, .spoiler-box__title:after, .entry-tag a, .entry-tag a:before, .entry-tag a:active, .entry-tag a:focus, .entry-tag a:hover, .search-icon:hover:before, .search-form .search-submit:hover:before, .star-rating-item.hover,
        .star-rating--score-1:not(.hover) .star-rating-item:nth-child(1),
        .star-rating--score-2:not(.hover) .star-rating-item:nth-child(1), .star-rating--score-2:not(.hover) .star-rating-item:nth-child(2),
        .star-rating--score-3:not(.hover) .star-rating-item:nth-child(1), .star-rating--score-3:not(.hover) .star-rating-item:nth-child(2), .star-rating--score-3:not(.hover) .star-rating-item:nth-child(3),
        .star-rating--score-4:not(.hover) .star-rating-item:nth-child(1), .star-rating--score-4:not(.hover) .star-rating-item:nth-child(2), .star-rating--score-4:not(.hover) .star-rating-item:nth-child(3), .star-rating--score-4:not(.hover) .star-rating-item:nth-child(4),
        .star-rating--score-5:not(.hover) .star-rating-item:nth-child(1), .star-rating--score-5:not(.hover) .star-rating-item:nth-child(2), .star-rating--score-5:not(.hover) .star-rating-item:nth-child(3), .star-rating--score-5:not(.hover) .star-rating-item:nth-child(4), .star-rating--score-5:not(.hover) .star-rating-item:nth-child(5)',
        [ 'color:%s', 'color_main' ]
    );

    $class_customizer_css->add(
        'body',
        [ 'color:%s', 'color_text' ]
    );

    $class_customizer_css->add(
        'a, a:visited, .spanlink, .comment-reply-link, .pseudo-link, .widget_calendar a, .widget_recent_comments a, .child-categories ul li a',
        [ 'color:%s', 'color_link' ]
    );

    $class_customizer_css->add(
        '.child-categories ul li a',
        [ 'border-color:%s', 'color_link' ]
    );

    $class_customizer_css->add(
        'a:hover, a:focus, a:active, .spanlink:hover, .comment-reply-link:hover, .pseudo-link:hover, .child-categories ul li a:hover',
        [ 'color:%s', 'color_link_hover' ]
    );

    $class_customizer_css->add(
        '.child-categories ul li a:hover, .post-box--no-thumb a:hover',
        [ 'border-color:%s', 'color_link_hover' ]
    );

    $class_customizer_css->add(
        '.post-box--card:hover',
        [ 'box-shadow: inset 0 0 0 1px %s', 'color_link_hover' ]
    );

    $class_customizer_css->add(
        '.post-box--card:hover',
        [ '-webkit-box-shadow: inset 0 0 0 1px %s', 'color_link_hover' ]
    );

    $class_customizer_css->add(
        '.site-header',
        [ 'background-color:%s', 'color_header_bg' ]
    );

    $class_customizer_css->add(
        '.site-title,.site-title a',
        [ 'color:%s', 'color_logo' ]
    );

    $class_customizer_css->add(
        '.site-description',
        [ 'color:%s', 'color_site_description' ]
    );

    $class_customizer_css->add(
        '.footer-navigation ul li a, .main-navigation ul li a, .footer-navigation ul li span, .main-navigation ul li span',
        [ 'color:%s', 'color_menu' ]
    );

    $class_customizer_css->add(
        '.site-footer',
        [ 'background-color:%s', 'color_footer_bg' ]
    );


    // background
    if ( $wpshop_core->get_option( 'header_bg_mob' ) == 'yes' ) {
        $class_customizer_css->add(
            '.site-header',
            [ 'background-image: url("%s")', 'header_bg' ]
        );

        $class_customizer_css->add(
            '.site-header',
            [ 'background-repeat:%s', 'header_bg_repeat' ]
        );

        $class_customizer_css->add(
            '.site-header',
            [ 'background-position:%s', 'header_bg_position' ]
        );

        $class_customizer_css->add(
            '.site-header',
            [ 'background-size: cover', '' ],
            '(max-width: 767px)'
        );
    } else {
        $class_customizer_css->add(
            '.site-header',
            [ 'background-image: url("%s")', 'header_bg' ],
            '(min-width: 768px)'
        );

        $class_customizer_css->add(
            '.site-header',
            [ 'background-repeat:%s', 'header_bg_repeat' ],
            '(min-width: 768px)'
        );

        $class_customizer_css->add(
            '.site-header',
            [ 'background-position:%s', 'header_bg_position' ],
            '(min-width: 768px)'
        );
    }


    // pattern
    $class_customizer_css->add(
        'body',
        [ 'background-image:url(' . get_bloginfo('template_url') . '/assets/images/backgrounds/%s)', 'bg_pattern' ]
    );


    $output = $class_customizer_css->output();
    if ( ! empty( $output ) ) {
        echo PHP_EOL . '    <style>' . $output . '</style>'.PHP_EOL;
    }
}
add_action( 'wp_head', 'wpshop_customizer_css', 10 );