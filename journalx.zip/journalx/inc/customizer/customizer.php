<?php
/**
 * ****************************************************************************
 *
 *   НЕ РЕДАКТИРУЙТЕ ЭТОТ ФАЙЛ
 *   DON'T EDIT THIS FILE
 *
 * *****************************************************************************
 *
 * @package journalx
 */

global $wpshop_customizer;
global $wpshop_core;
global $wpshop_social;

add_action( 'customize_register', function( $wp_customize ) use ( $wpshop_core, $wpshop_customizer, $wpshop_social ) {

    $customizer_controls = [

        'layout' => [
            'title'    => __( 'Layout', THEME_TEXTDOMAIN ),
            'priority' => 10,

            'sections' => [

                'header' => [
                    'title'       => __( 'Header', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can customize the width and height of the header', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/settings/#structure-header" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'header_width' => [
                            'label'   => __( 'Header width', THEME_TEXTDOMAIN ),
                            'type'    => 'select',
                            'choices' => [
                                'full'  => __( 'Full width', THEME_TEXTDOMAIN ),
                                'fixed' => __( 'Fixed width', THEME_TEXTDOMAIN )
                            ],
                        ],

                        'header_padding_top' => [
                            'label'       => __( 'Header padding top', THEME_TEXTDOMAIN ),
                            'type'        => 'range',
                            'sanitize'    => 'integer',
                            'description' => __( 'You can set padding top and bottom, ex. for background image', THEME_TEXTDOMAIN ),
                            'input_attrs' => [ 'min' => 0, 'max' => 200, 'step' => 1 ],
                        ],

                        'header_padding_bottom' => [
                            'label'       => __( 'Header padding bottom', THEME_TEXTDOMAIN ),
                            'type'        => 'range',
                            'sanitize'    => 'integer',
                            'input_attrs' => [ 'min' => 0, 'max' => 200, 'step' => 1 ],
                        ],

                        'header_fixed' => [
                            'label' => __( 'Fixed header', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                    ],
                ],

                'footer' => [
                    'title'       => __( 'Footer', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can customize the width of the footer', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/settings/#structure-footer" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'footer_width' => [
                            'label'   => __( 'Footer width', THEME_TEXTDOMAIN ),
                            'type'    => 'select',
                            'choices' => [
                                'full'  => __( 'Full width', THEME_TEXTDOMAIN ),
                                'fixed' => __( 'Fixed width', THEME_TEXTDOMAIN )
                            ],
                        ],

                    ],
                ],
            ],
        ],


        'structure' => [
            'title'    => __( 'Blocks', THEME_TEXTDOMAIN ),
            'priority' => 12,

            'sections' => [

                'header' => [
                    'title'       => __( 'Header', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can customize the appearance of the header', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/settings/#blocks-header" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'logotype_image' => [
                            'name'  => 'logotype_image',
                            'label' => __( 'Logotype', THEME_TEXTDOMAIN ),
                            'type'  => 'image',
                        ],

                        'logotype_max_width' => [
                            'label'       => __( 'Logotype max width, px', THEME_TEXTDOMAIN ),
                            'type'        => 'number',
                            'input_attrs' => [ 'min' => 20, 'max' => 1000, 'step' => 1 ],
                        ],

                        'logotype_max_height' => [
                            'label'       => __( 'Logotype max height, px', THEME_TEXTDOMAIN ),
                            'type'        => 'number',
                            'input_attrs' => [ 'min' => 20, 'max' => 500, 'step' => 1 ],
                        ],

                        'header_hide_title' => [
                            'label'       => __( 'Hide site title and description', THEME_TEXTDOMAIN ),
                            'type'        => 'checkbox',
                            'description' => __( 'If you hide the title and description, it is desirable to set for the main page h1, for example, in the section "Blocks" -> "Home"', THEME_TEXTDOMAIN ),
                        ],

                        'header_social' => [
                            'label'       => __( 'Show social links', THEME_TEXTDOMAIN ),
                            'type'        => 'checkbox',
                            'description' => __( 'Links to social networks can be set in Modules -> Social Profiles', THEME_TEXTDOMAIN ),
                        ],

                        'header_html_block_1' => [
                            'label'       => __( 'HTML code #1', THEME_TEXTDOMAIN ),
                            'type'        => 'textarea',
                            'description' => __( 'Code will be displayed after logotype', THEME_TEXTDOMAIN ),
                        ],

                        'header_html_block_2' => [
                            'label'       => __( 'HTML code #2', THEME_TEXTDOMAIN ),
                            'type'        => 'textarea',
                            'description' => __( 'Code will be displayed after top menu', THEME_TEXTDOMAIN ),
                        ],

                        'header_search' => [
                            'label' => __( 'Show search', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],
                    ],
                ],

                'footer' => [
                    'title'       => __( 'Footer', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can customize the appearance of the footer', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/settings/#blocks-footer" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'footer_copyright'  => [
                            'label'       => __( 'Copyright', THEME_TEXTDOMAIN ),
                            'description' => __( 'Use %year% to add the current year', THEME_TEXTDOMAIN ),
                            'type'        => 'textarea',
                        ],

                        'footer_social' => [
                            'label'       => __( 'Show social links', THEME_TEXTDOMAIN ),
                            'type'        => 'checkbox',
                            'description' => __( 'Links to social networks can be set in Modules -> Social Profiles', THEME_TEXTDOMAIN ),
                        ],

                        'footer_html_block_1' => [
                            'label' => __( 'HTML code #1', THEME_TEXTDOMAIN ),
                            'type'  => 'textarea',
                        ],

                        'footer_html_block_2' => [
                            'label' => __( 'HTML code #2', THEME_TEXTDOMAIN ),
                            'type'  => 'textarea',
                        ],

                        'footer_counters' => [
                            'label' => __( 'Counters and analytics', THEME_TEXTDOMAIN ),
                            'type'  => 'textarea',
                        ],

                    ],
                ],

                'home' => [
                    'title'       => __( 'Home', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can customize the appearance of the home page', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/settings/#blocks-main" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'structure_home_h1' => [
                            'label'       => __( 'Header H1', THEME_TEXTDOMAIN ),
                            'description' => __( 'If the field is not specified, the logo (site name) becomes the h1 header', THEME_TEXTDOMAIN ),
                        ],

                        'structure_home_text' => [
                            'label'       => __( 'Text', THEME_TEXTDOMAIN ),
                            'type'        => 'textarea',
                            'description' => __( 'The text under the heading H1 is displayed only on the main', THEME_TEXTDOMAIN ),
                        ],

                        'structure_home_position' => [
                            'label'   => __( 'H1 and text position', THEME_TEXTDOMAIN ),
                            'type'    => 'radio',
                            'choices' => [
                                'top'    => __( 'Top', THEME_TEXTDOMAIN ),
                                'bottom' => __( 'Bottom', THEME_TEXTDOMAIN ),
                            ],
                        ]

                    ],
                ],

                'single' => [
                    'title'       => __( 'Single', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can customize the appearance of the post', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/settings/#blocks-post" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'structure_single_sidebar' => [
                            'label' => __( 'Show sidebar', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'structure_single_hide' => [
                            'label'   => __( 'Hide elements', THEME_TEXTDOMAIN ),
                            'type'    => 'multicheck',
                            'choices' => [
                                'thumbnail'      => __( 'Thumbnail', THEME_TEXTDOMAIN ),
                                'date'           => __( 'Date', THEME_TEXTDOMAIN ),
                                'category'       => __( 'Category', THEME_TEXTDOMAIN ),
                                'author'         => __( 'Author', THEME_TEXTDOMAIN ),
                                'comments_count' => __( 'Comments count', THEME_TEXTDOMAIN ),
                                'views'          => __( 'Views count', THEME_TEXTDOMAIN ),
                                'excerpt'        => __( 'Excerpt', THEME_TEXTDOMAIN ),
                                'tags'           => __( 'Tags', THEME_TEXTDOMAIN ),
                                'rating'         => __( 'Rating', THEME_TEXTDOMAIN ),
                                'author_box'     => __( 'Author block', THEME_TEXTDOMAIN ),
                                'comments'       => __( 'Comments', THEME_TEXTDOMAIN ),
                                'social_buttons' => __( 'Social buttons', THEME_TEXTDOMAIN ),
                            ],
                        ],

                        'structure_single_related' => [
                            'label'       => __( 'Count of related articles', THEME_TEXTDOMAIN ),
                            'type'        => 'number',
                            'input_attrs' => [ 'min' => 0, 'max' => 50, 'step' => 1 ],
                            'description' => __( '0 - for disable, maximum 50', THEME_TEXTDOMAIN ),
                        ],

                    ],
                ],

                'page' => [
                    'title'       => __( 'Page', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can customize the appearance of the page', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/settings/#blocks-page" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'structure_page_sidebar' => [
                            'label' => __( 'Show sidebar', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'structure_page_hide' => [
                            'label'   => __( 'Hide elements', THEME_TEXTDOMAIN ),
                            'type'    => 'multicheck',
                            'choices' => [
                                'thumbnail'      => __( 'Thumbnail', THEME_TEXTDOMAIN ),
                                'rating'         => __( 'Rating', THEME_TEXTDOMAIN ),
                                'comments'       => __( 'Comments', THEME_TEXTDOMAIN ),
                                'social_buttons' => __( 'Social buttons', THEME_TEXTDOMAIN ),
                            ],
                        ],

                        'structure_page_related' => [
                            'label'       => __( 'Count of related articles', THEME_TEXTDOMAIN ),
                            'type'        => 'number',
                            'input_attrs' => [ 'min' => 0, 'max' => 50, 'step' => 1 ],
                            'description' => __( '0 - for disable, maximum 50', THEME_TEXTDOMAIN ),
                        ],

                    ],
                ],

                'archive' => [
                    'title'       => __( 'Archive', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can customize the appearance of the archive', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/settings/#blocks-archive" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'structure_archive_description_show' => [
                            'label' => __( 'Show description', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'structure_archive_subcategories' => [
                            'label' => __( 'Show subcategories', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'structure_archive_description' => [
                            'label'   => __( 'Position of archive description', THEME_TEXTDOMAIN ),
                            'type'    => 'radio',
                            'choices' => [
                                'top'    => __( 'Top', THEME_TEXTDOMAIN ),
                                'bottom' => __( 'Bottom', THEME_TEXTDOMAIN ),
                            ],
                        ],

                    ],
                ],

                'comments' => [
                    'title'       => __( 'Comments', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can customize the appearance of the comments', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/settings/#blocks-comments" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'comments_text_before_submit' => [
                            'label'       => __( 'Text before Send button', THEME_TEXTDOMAIN ),
                            'type'        => 'textarea',
                            'description' => 'Вы можете добавить любой HTML код, пример с ссылками (# нужно заменить на адрес ссылки):<br><br>Нажимая на кнопку "Отправить комментарий", я даю согласие на &lt;a href="#"&gt;обработку персональных данных&lt;/a&gt; и принимаю &lt;a href="#" target="_blank"&gt;политику конфиденциальности&lt;/a&gt;.',
                        ],

                        'comments_date' => [
                            'label' => __( 'Show comment date', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'comments_time' => [
                            'label' => __( 'Show comment time', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'comments_output' => [
                            'label' => __( 'Replace uploaded comments with static', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                    ],
                ],

                'search' => [
                    'title'       => __( 'Search', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can customize the appearance of the search page', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/settings/#blocks-search" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'structure_search_with_results_title' => [
                            'label' => __( 'Title with search results', THEME_TEXTDOMAIN ),
                        ],

                        'structure_search_without_results_title' => [
                            'label' => __( 'Title without search results', THEME_TEXTDOMAIN ),
                        ],

                        'structure_search_without_results_text' => [
                            'label' => __( 'Text without search results', THEME_TEXTDOMAIN ),
                            'type'  => 'textarea',
                        ],

                        'structure_search_form_show' => [
                            'label' => __( 'Show search form', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'structure_search_related_show' => [
                            'label' => __( 'Show related posts', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                    ],
                ],

                '404' => [
                    'title'       => __( '404', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can customize the appearance of the 404 page', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/settings/#blocks-404" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'structure_404_title' => [
                            'label' => __( 'Title', THEME_TEXTDOMAIN ),
                        ],

                        'structure_404_text' => [
                            'label' => __( 'Text', THEME_TEXTDOMAIN ),
                            'type'  => 'textarea',
                        ],

                        'structure_404_search_form_show' => [
                            'label' => __( 'Show search form', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'structure_404_related_show' => [
                            'label' => __( 'Show related posts', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                    ],
                ],
            ],
        ],


        'modules' => [
            'title'    => __( 'Modules', THEME_TEXTDOMAIN ),
            'priority' => 12,

            'sections' => [

                'toc' => [
                    'title'       => __( 'Contents', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can customize the toc', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/modules/#toc-content" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'toc_display' => [
                            'label' => __( 'Enable on posts', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'toc_display_pages' => [
                            'label' => __( 'Enable on pages', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'toc_open' => [
                            'label' => __( 'Default open', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'toc_noindex' => [
                            'label' => __( 'Wrap the content in noindex', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'toc_place' => [
                            'label' => __( 'Display the content at the beginning of the post', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'toc_title' => [
                            'label' => __( 'Content title', THEME_TEXTDOMAIN ),
                        ],

                    ],
                ],

                'lightbox' => [
                    'title'       => __( 'Lightbox', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can turn on the enlargement of the picture when you click on it', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/modules/#lightbox" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'lightbox_display' => [
                            'label' => __( 'Enable lightbox', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                    ],
                ],

                'breadcrumbs' => [
                    'title'       => __( 'Breadcrumbs', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can customize the breadcrumbs', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/modules/#breadcrumbs" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'breadcrumbs_display' => [
                            'label' => __( 'Enable breadcrumbs', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'breadcrumbs_home_text' => [
                            'label' => __( 'Home text', THEME_TEXTDOMAIN ),
                        ],

                        'breadcrumbs_archive' => [
                            'label' => __( 'Show breadcrumbs in archives', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'breadcrumbs_single_link' => [
                            'label' => __( 'Display page title', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                    ],
                ],

                'author_block' => [
                    'title'       => __( 'Author block', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can customize the author block', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/modules/#author-block" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'author_link' => [
                            'label' => __( 'Display a link to the author’s page', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'author_link_target' => [
                            'label' => __( 'Open link in new window', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'author_social_enable' => [
                            'label'       => __( 'Display author social profiles', THEME_TEXTDOMAIN ),
                            'type'        => 'checkbox',
                            'description' => __( 'Links to social profiles author can be set in Users', THEME_TEXTDOMAIN ),

                        ],

                        'author_social_title' => [
                            'label' => __( 'Social profiles title', THEME_TEXTDOMAIN ),
                        ],

                        'author_social_title_show' => [
                            'label' => __( 'Show title social profiles', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'author_social_js' => [
                            'label' => __( 'Hide links social profiles by JS', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                    ],
                ],

                'contact_form' => [
                    'title'       => __( 'Contact Form', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can customize the contact form', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/modules/#contact-form" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'contact_form_text_before_submit' => [
                            'label'       => __( 'Text before Send button', THEME_TEXTDOMAIN ),
                            'type'        => 'textarea',
                            'description' => 'Вы можете добавить любой HTML код, пример с ссылками (# нужно заменить на адрес ссылки):<br><br>Нажимая на кнопку "Отправить комментарий", я даю согласие на &lt;a href="#"&gt;обработку персональных данных&lt;/a&gt; и принимаю &lt;a href="#" target="_blank"&gt;политику конфиденциальности&lt;/a&gt;.',
                        ],

                    ],
                ],

                'social_profiles' => [
                    'title'       => __( 'Social profiles', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can customize the social profiles', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/modules/#social-profiles" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'social_facebook' => [
                            'label' => __( 'Facebook', THEME_TEXTDOMAIN ),
                        ],

                        'social_vkontakte' => [
                            'label' => __( 'Vk', THEME_TEXTDOMAIN ),
                        ],

                        'social_twitter' => [
                            'label' => __( 'Twitter', THEME_TEXTDOMAIN ),
                        ],

                        'social_odnoklassniki' => [
                            'label' => __( 'Odnoklassniki', THEME_TEXTDOMAIN ),
                        ],

                        'social_telegram' => [
                            'label' => __( 'Telegram', THEME_TEXTDOMAIN ),
                        ],

                        'social_youtube' => [
                            'label' => __( 'Youtube', THEME_TEXTDOMAIN ),
                        ],

                        'social_instagram' => [
                            'label' => __( 'Instagram', THEME_TEXTDOMAIN ),
                        ],

                        'social_tiktok' => [
                            'label' => __( 'Tik Tok', THEME_TEXTDOMAIN ),
                        ],

                        'social_linkedin' => [
                            'label' => __( 'Linkedin', THEME_TEXTDOMAIN ),
                        ],

                        'social_whatsapp' => [
                            'label' => __( 'WhatsApp', THEME_TEXTDOMAIN ),
                        ],

                        'social_viber' => [
                            'label' => __( 'Viber', THEME_TEXTDOMAIN ),
                        ],

                        'social_pinterest' => [
                            'label' => __( 'Pinterest', THEME_TEXTDOMAIN ),
                        ],

                        'social_yandexzen' => [
                            'label' => __( 'Yandex Zen', THEME_TEXTDOMAIN ),
                        ],

                        'social_github' => [
                            'label' => __( 'GitHub', THEME_TEXTDOMAIN ),
                        ],

                        'social_discord' => [
                            'label' => __( 'Discord', THEME_TEXTDOMAIN ),
                        ],

                        'social_rutube' => [
                            'label' => __( 'RuTube', THEME_TEXTDOMAIN ),
                        ],

                        'social_yappy' => [
                            'label' => __( 'Yappy', THEME_TEXTDOMAIN ),
                        ],

                        'social_pikabu' => [
                            'label' => __( 'Pikabu', THEME_TEXTDOMAIN ),
                        ],

                        'social_yandex' => [
                            'label' => __( 'Yandex', THEME_TEXTDOMAIN ),
                        ],

                        'structure_social_js' => [
                            'label' => __( 'Hide links by JS', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                    ],
                ],

                'share_buttons' => [
                    'title'       => __( 'Share buttons', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can customize the share buttons', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/modules/#share-buttons" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'share_buttons_counters' => [
                            'label' => __( 'Enable counters', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'share_buttons' => [
                            'type'    => 'sortable-checkboxes',
                            'label'   => __( 'Share buttons', THEME_TEXTDOMAIN ),
                            'choices' => $wpshop_social->get_share_services(),
                        ],

                    ],
                ],

                'sitemap' => [
                    'title'       => __( 'Sitemap', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can customize the sitemap', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/modules/#sitemap" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'sitemap_category_exclude' => [
                            'label'       => __( 'ID of categories to exclude', THEME_TEXTDOMAIN ),
                            'description' => __( 'Enter the ID of the categories separated by commas to exclude them from the sitemap', THEME_TEXTDOMAIN ),
                        ],

                        'sitemap_posts_exclude' => [
                            'label' => __( 'ID of posts to exclude', THEME_TEXTDOMAIN ),
                            'description' => __( 'Enter the ID of the posts separated by commas to exclude them from the sitemap', THEME_TEXTDOMAIN ),
                        ],

                        'sitemap_pages_show' => [
                            'label' => __( 'Show pages in sitemap', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'sitemap_pages_exclude' => [
                            'label' => __( 'ID of pages to exclude', THEME_TEXTDOMAIN ),
                            'description' => __( 'Enter the ID of the pages separated by commas to exclude them from the sitemap', THEME_TEXTDOMAIN ),
                        ],

                    ],
                ],

                'related_posts' => [
                    'title'       => __( 'Related posts', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can customize the related posts', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/modules/#related-posts" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'related_posts_title' => [
                            'label' => __( 'Related posts title', THEME_TEXTDOMAIN ),
                        ],

                        'related_post_taxonomy_order' => [
                            'label'       => __( 'Order related posts', THEME_TEXTDOMAIN ),
                            'type'        => 'select',
                            'choices'     => [
                                'categories' => __( 'By categories', THEME_TEXTDOMAIN ),
                                'tags'       => __( 'By tags', THEME_TEXTDOMAIN ),
                            ],
                            'description' => __( 'In related posts, posts from the same category\tag are displayed first, and then, if there is not enough related articles to the specified number, they are displayed randomly', THEME_TEXTDOMAIN ),
                        ],

                        'related_posts_exclude' => [
                            'label'       => __( 'ID of posts to exclude', THEME_TEXTDOMAIN ),
                            'description' => __( 'You can specify the ID of the posts separated by commas to exclude them from the related posts', THEME_TEXTDOMAIN ),
                        ],

                        'related_posts_category_exclude' => [
                            'label'       => __( 'ID of categories to exclude', THEME_TEXTDOMAIN ),
                            'description' => __( 'You can specify the ID of categories separated by commas to exclude them from the related posts', THEME_TEXTDOMAIN ),
                        ],

                    ],
                ],

                'arrow' => [
                    'title'       => __( 'Scroll to top button', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can customize the top button', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/modules/#top-button" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'structure_arrow' => [
                            'label' => __( 'Enable scroll to top button', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'structure_arrow_mob' => [
                            'label' => __( 'Enable on mobile', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'structure_arrow_bg' => [
                            'label' => __( 'Background color', THEME_TEXTDOMAIN ),
                            'type'  => 'color',
                        ],

                        'structure_arrow_color' => [
                            'label' => __( 'Arrow color', THEME_TEXTDOMAIN ),
                            'type'  => 'color',
                        ],

                        'structure_arrow_width' => [
                            'label'       => __( 'Button width', THEME_TEXTDOMAIN ),
                            'type'        => 'range',
                            'sanitize'    => 'integer',
                            'input_attrs' => [ 'min' => 30, 'max' => 80, 'step' => 1 ],
                        ],

                        'structure_arrow_height' => [
                            'label'       => __( 'Button height', THEME_TEXTDOMAIN ),
                            'type'        => 'range',
                            'sanitize'    => 'integer',
                            'input_attrs' => [ 'min' => 30, 'max' => 80, 'step' => 1 ],
                        ],

                        'structure_arrow_position' => [
                            'label'   => __( 'Button position', THEME_TEXTDOMAIN ),
                            'type'    => 'select',
                            'choices' => [
                                'left'  => __( 'Left', THEME_TEXTDOMAIN ),
                                'right' => __( 'Right', THEME_TEXTDOMAIN ),
                            ],
                        ],

                        'structure_arrow_icon' => [
                            'label'   => __( 'Button icon', THEME_TEXTDOMAIN ),
                            'type'    => 'select',
                            'choices' => [
                                '\2b9d' => '⮝',
                                '\2b85' => '⮅',
                                '\2b61' => '⭡',
                                '\2b06' => '⬆',
                                '\25b3' => '△',
                            ],
                        ],

                    ],
                ],

                'views_counter' => [
                    'title'       => __( 'Views counter', THEME_TEXTDOMAIN ),
                    'description' => __( 'In this section, you can customize the views counter', THEME_TEXTDOMAIN ) . ' <a href="https://support.wpshop.ru/docs/themes/journalx/modules/#views-counter" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'wpshop_views_counter_enable' => [
                            'label' => __( 'Enable view counter', THEME_TEXTDOMAIN ),
                            'type'  => 'checkbox',
                        ],

                        'wpshop_views_counter_to_count' => [
                            'label'   => __( 'Count views', THEME_TEXTDOMAIN ),
                            'type'    => 'select',
                            'choices' => [
                                '0' => __( 'Everyone', THEME_TEXTDOMAIN ),
                                '1' => __( 'Only guests', THEME_TEXTDOMAIN ),
                                '2' => __( 'Only registered users', THEME_TEXTDOMAIN ),
                            ],
                        ],

                        'wpshop_views_counter_exclude_bots' => [
                            'label'   => __( 'Exclude bot views', THEME_TEXTDOMAIN ),
                            'type'    => 'select',
                            'choices' => [
                                '0' => __( 'No', THEME_TEXTDOMAIN ),
                                '1' => __( 'Yes', THEME_TEXTDOMAIN ),
                            ],
                        ],

                    ],
                ],
            ],
        ],


        'post_cards' => [
            'title'       => __( 'Post cards', THEME_TEXTDOMAIN ),
            'description' => __( 'In this section, you can customize the appearance of postcards that are displayed on the main, in headings, search, etc.', THEME_TEXTDOMAIN ),
            'priority'    => 12,

            'sections' => [

                'post_card_standard' => [
                    'title' => __( 'Main', THEME_TEXTDOMAIN ),

                    'controls' => [

                        'structure_posts_tag' => [
                            'label'   => __( 'Header tag', THEME_TEXTDOMAIN ),
                            'type'    => 'radio',
                            'choices' => [
                                'h2'  => 'h2',
                                'div' => 'div',
                            ],
                        ],

                        'post_card_main_order' => [
                            'type'    => 'sortable-checkboxes',
                            'label'   => __( 'Order', THEME_TEXTDOMAIN ),
                            //'description' => __( 'Category is displayed only when there is no thumbnail', THEME_TEXTDOMAIN ),
                            'choices' => [
                                'thumbnail' => __( 'Thumbnail', THEME_TEXTDOMAIN ),
                                'category'  => __( 'Category', THEME_TEXTDOMAIN ),
                                'title'     => __( 'Title', THEME_TEXTDOMAIN ),
                                'meta'      => __( 'Meta', THEME_TEXTDOMAIN ),
                                'excerpt'   => __( 'Excerpt', THEME_TEXTDOMAIN ),
                                'rating'    => __( 'Rating', THEME_TEXTDOMAIN ),
                            ],
                        ],

                        'post_card_main_order_meta' => [
                            'type'    => 'sortable-checkboxes',
                            'label'   => __( 'Order Meta', THEME_TEXTDOMAIN ),
                            'choices' => [
                                'date'            => __( 'Date', THEME_TEXTDOMAIN ),
                                'author'          => __( 'Author', THEME_TEXTDOMAIN ),
                                'comments_number' => __( 'Comments count', THEME_TEXTDOMAIN ),
                                'views'           => __( 'Views count', THEME_TEXTDOMAIN ),
                            ],
                        ],

                        'post_card_main_excerpt_length' => [
                            'label' => __( 'Excerpt length', THEME_TEXTDOMAIN ),
                            'type'  => 'number',
                        ],


                    ],
                ],

                'post_card_related' => [
                    'title' => __( 'Related posts', THEME_TEXTDOMAIN ),

                    'controls' => [

                        'structure_posts_related_tag' => [
                            'label'   => __( 'Header tag', THEME_TEXTDOMAIN ),
                            'type'    => 'radio',
                            'choices' => [
                                'h2'  => 'h2',
                                'div' => 'div',
                            ],
                        ],

                        'post_card_related_order' => [
                            'type'    => 'sortable-checkboxes',
                            'label'   => __( 'Order', THEME_TEXTDOMAIN ),
                            'choices' => [
                                'thumbnail' => __( 'Thumbnail', THEME_TEXTDOMAIN ),
                                'title'     => __( 'Title', THEME_TEXTDOMAIN ),
                                'meta'      => __( 'Meta', THEME_TEXTDOMAIN ),
                                'excerpt'   => __( 'Excerpt', THEME_TEXTDOMAIN ),
                                'rating'    => __( 'Rating', THEME_TEXTDOMAIN ),
                            ],
                        ],

                        'post_card_related_order_meta' => [
                            'type'    => 'sortable-checkboxes',
                            'label'   => __( 'Order Meta', THEME_TEXTDOMAIN ),
                            'choices' => [
                                'comments_number' => __( 'Comments count', THEME_TEXTDOMAIN ),
                                'views'           => __( 'Views count', THEME_TEXTDOMAIN ),
                            ]
                        ],

                        'post_card_related_excerpt_length' => [
                            'label' => __( 'Excerpt length', THEME_TEXTDOMAIN ),
                            'type'  => 'number',
                        ],

                    ],
                ],

            ],
        ],


        'codes' => [
            'title'    => __( 'Codes', THEME_TEXTDOMAIN ),
            'priority' => 13,

            'controls' => [

                'code_head' => [
                    'label'       => __( 'In &lt;head&gt; section', THEME_TEXTDOMAIN ),
                    'description' => __( 'Before &lt;/head&gt; tag', THEME_TEXTDOMAIN ),
                    'type'        => 'textarea',
                ],

                'code_body' => [
                    'label' => __( 'Before &lt;/body&gt;', THEME_TEXTDOMAIN ),
                    'type'  => 'textarea',
                ],

                'code_after_content' => [
                    'label' => __( 'After content', THEME_TEXTDOMAIN ),
                    'type'  => 'textarea',
                ]

            ],
        ],


        'infinity_scroll' => [
            'title'    => __( 'Loading posts', THEME_TEXTDOMAIN ),
            'priority' => 13,

            'controls' => [

                'infinity_scroll_archive_enabled' => [
                    'label'       => __( 'Enable uploading of postcards on the main and archives', THEME_TEXTDOMAIN ),
                    'type'        => 'checkbox',
                ],

                'infinity_scroll_archive_limit' => [
                    'label'       => __( 'Maximum loadable post cards on the main and archives', THEME_TEXTDOMAIN ),
                    'type'        => 'number',
                    'input_attrs' => [ 'min' => 1, 'max' => 50, 'step' => 1 ],
                    'description' => __( 'We recommend setting a small value, for example 10-15', THEME_TEXTDOMAIN ),
                ],

                'infinity_scroll_single_enabled' => [
                    'label' => __( 'Enable loading next posts when scrolling in the posts', THEME_TEXTDOMAIN ),
                    'type'  => 'checkbox',
                ],

                'infinity_scroll_single_category' => [
                    'label' => __( 'Load posts only from post category', THEME_TEXTDOMAIN ),
                    'type'  => 'checkbox',
                ],

                'infinity_scroll_single_limit' => [
                    'label'       => __( 'Maximum loading posts when scrolling in the post', THEME_TEXTDOMAIN ),
                    'type'        => 'number',
                    'input_attrs' => [ 'min' => 1, 'max' => 50, 'step' => 1 ],
                    'description' => __( 'We recommend setting a small value, for example 10-15', THEME_TEXTDOMAIN ),
                ],

                'loaded_content_height' => [
                    'label'       => __( 'Show start of loaded posts', THEME_TEXTDOMAIN ),
                    'type'        => 'number',
                    'input_attrs' => [ 'min' => 0, 'step' => 1 ],
                    'description' => __( 'Specify the height of the loaded posts in pixels. If set to 0 - posts will be displayed in full', THEME_TEXTDOMAIN ),
                ],

                'yandex_metrika_id' => [
                    'label' => sprintf( esc_html__( 'Counter number in Yandex Metric to account for the loading of new posts in the post. For example: %s', THEME_TEXTDOMAIN ), '0123456' ),
                ],

                'ga_tracking_id' => [
                    'label' => sprintf( esc_html__( 'Counter number in Google Analytics for new posts in the post. For example: %s', THEME_TEXTDOMAIN ), 'UA-0123456-1' ),
                ],

            ],
        ],


        'typography' => [
            'title'    => __( 'Typography', THEME_TEXTDOMAIN ),
            'priority' => 15,

            'sections' => [

                'typography_general' => [
                    'title' => __( 'General', THEME_TEXTDOMAIN ),

                    'controls' => [

                        'typography_body' => [
                            'label'   => __( 'Main text', THEME_TEXTDOMAIN ),
                            'type'    => 'typography',
                            'choices' => [ 'font-family', 'font-size', 'font-style', 'line-height' ],
                        ]

                    ]
                ],

                'typography_header' => [
                    'title' => __( 'Header', THEME_TEXTDOMAIN ),

                    'controls' => [

                        'typography_site_title' => [
                            'label'   => __( 'Site title', THEME_TEXTDOMAIN ),
                            'type'    => 'typography',
                            'choices' => [ 'font-family', 'font-size', 'font-style', 'line-height' ],
                        ],

                        'typography_site_description' => [
                            'label'   => __( 'Site description', THEME_TEXTDOMAIN ),
                            'type'    => 'typography',
                            'choices' => [ 'font-family', 'font-size', 'font-style', 'line-height' ],
                        ]

                    ],
                ],

                'typography_menu' => [
                    'title' => __( 'Menu', THEME_TEXTDOMAIN ),

                    'controls' => [

                        'typography_menu_links' => [
                            'label'   => __( 'Links in the menu', THEME_TEXTDOMAIN ),
                            'type'    => 'typography',
                            'choices' => [ 'font-family', 'font-size', 'font-style', 'line-height'],
                        ],
                    ],
                ],

                'typography_headers' => [
                    'title'       => __( 'Headers', THEME_TEXTDOMAIN ),
                    'description' => __( 'Font sizes of headings are in relative em units', THEME_TEXTDOMAIN ) . ' <a href="https://wpschool.ru/edinitsy-izmereniya-css/" target="_blank" rel="noopener" class="journalx-ico-help" title="' . __( 'Help', THEME_TEXTDOMAIN ) . '">?</a>',

                    'controls' => [

                        'typography_header_h1' => [
                            'label'   => __( 'Header H1', THEME_TEXTDOMAIN ),
                            'type'    => 'typography',
                            'choices' => [ 'font-family', 'font-size', 'font-style', 'line-height' ],
                        ],

                        'typography_header_h2' => [
                            'label'   => __( 'Header H2', THEME_TEXTDOMAIN ),
                            'type'    => 'typography',
                            'choices' => [ 'font-family', 'font-size', 'font-style', 'line-height' ],
                        ],

                        'typography_header_h3' => [
                            'label'   => __( 'Header H3', THEME_TEXTDOMAIN ),
                            'type'    => 'typography',
                            'choices' => [ 'font-family', 'font-size', 'font-style', 'line-height' ],
                        ],

                        'typography_header_h4' => [
                            'label'   => __( 'Header H4', THEME_TEXTDOMAIN ),
                            'type'    => 'typography',
                            'choices' => [ 'font-family', 'font-size', 'font-style', 'line-height' ],
                        ],

                        'typography_header_h5' => [
                            'label'   => __( 'Header H5', THEME_TEXTDOMAIN ),
                            'type'    => 'typography',
                            'choices' => [ 'font-family', 'font-size', 'font-style', 'line-height' ],
                        ],

                        'typography_header_h6' => [
                            'label'   => __( 'Header H6', THEME_TEXTDOMAIN ),
                            'type'    => 'typography',
                            'choices' => [ 'font-family', 'font-size', 'font-style', 'line-height' ],
                        ]

                    ]
                ],

            ]
        ],


        'colors' => [
            'title'    => __( 'Colors', THEME_TEXTDOMAIN ),
            'priority' => 14,

            'controls' => [

                'color_main' => [
                    'label' => __( 'Base site color', THEME_TEXTDOMAIN ),
                    'type'  => 'color',
                ],

                'color_text' => [
                    'label' => __( 'Base text color', THEME_TEXTDOMAIN ),
                    'type'  => 'color',
                ],

                'color_link' => [
                    'label' => __( 'Link color', THEME_TEXTDOMAIN ),
                    'type'  => 'color',
                ],

                'color_link_hover' => [
                    'label' => __( 'Link hover color', THEME_TEXTDOMAIN ),
                    'type'  => 'color',
                ],

                'color_header_bg' => [
                    'label' => __( 'Header background color', THEME_TEXTDOMAIN ),
                    'type'  => 'color',
                ],

                'color_logo' => [
                    'label' => __( 'Site title color', THEME_TEXTDOMAIN ),
                    'type'  => 'color',
                ],

                'color_site_description' => [
                    'label' => __( 'Site description color', THEME_TEXTDOMAIN ),
                    'type'  => 'color',
                ],

                'color_menu' => [
                    'label' => __( 'Menu link color', THEME_TEXTDOMAIN ),
                    'type'  => 'color',
                ],

                'color_footer_bg' => [
                    'label' => __( 'Footer background color', THEME_TEXTDOMAIN ),
                    'type'  => 'color',
                ],

            ],
        ],


        'background_image' => [
            'title'    => __( 'Background', THEME_TEXTDOMAIN ),
            'priority' => 14,

            'controls' => [

                'body_bg_link' => [
                    'label' => __( 'Site background link', THEME_TEXTDOMAIN ),
                ],

                'body_bg_link_js' => [
                    'label' => __( 'Hide link background by JS', THEME_TEXTDOMAIN ),
                    'type'  => 'checkbox',
                ],

                'header_bg' => [
                    'label' => __( 'Header background', THEME_TEXTDOMAIN ),
                    'type'  => 'image',
                ],

                'header_bg_repeat' => [
                    'label'   => __( 'Header background repeat', THEME_TEXTDOMAIN ),
                    'type'    => 'select',
                    'choices' => [
                        'no-repeat' => __( 'No repeat', THEME_TEXTDOMAIN ),
                        'repeat'    => __( 'Repeat horizontal and vertical', THEME_TEXTDOMAIN ),
                        'repeat-x'  => __( 'Repeat horizontal', THEME_TEXTDOMAIN ),
                        'repeat-y'  => __( 'Repeat vertical', THEME_TEXTDOMAIN ),
                    ],
                ],

                'header_bg_position' => [
                    'label'   => __( 'Header background position', THEME_TEXTDOMAIN ),
                    'type'    => 'select',
                    'choices' => [
                        'left top'      => __( 'Top left', THEME_TEXTDOMAIN ),
                        'center top'    => __( 'Top center', THEME_TEXTDOMAIN ),
                        'right top'     => __( 'Top right', THEME_TEXTDOMAIN ),
                        'left center'   => __( 'Middle left', THEME_TEXTDOMAIN ),
                        'center center' => __( 'Middle center', THEME_TEXTDOMAIN ),
                        'right center'  => __( 'Middle right', THEME_TEXTDOMAIN ),
                        'left bottom'   => __( 'Bottom left', THEME_TEXTDOMAIN ),
                        'center bottom' => __( 'Bottom center', THEME_TEXTDOMAIN ),
                        'right bottom'  => __( 'Bottom right', THEME_TEXTDOMAIN ),
                    ],
                ],

                'header_bg_mob' => [
                    'label' => __( 'Display header background on mobile', THEME_TEXTDOMAIN ),
                    'type'  => 'checkbox',
                ],

            ],
        ],


        'tweak' => [
            'title'    => __( 'Tweak options', THEME_TEXTDOMAIN ),
            'priority' => 200,

            'controls' => [

                'social_share_title' => [
                    'label' => __( 'Social buttons title', THEME_TEXTDOMAIN ),
                ],

                'social_share_title_show' => [
                    'label' => __( 'Show title social buttons', THEME_TEXTDOMAIN ),
                    'type'  => 'checkbox',
                ],

                'rating_title' => [
                    'label' => __( 'Rating title', THEME_TEXTDOMAIN ),
                ],

                'rating_text_show' => [
                    'label' => __( 'Show rating statistics', THEME_TEXTDOMAIN ),
                    'type'  => 'checkbox',
                ],

                'advertising_page_display' => [
                    'label' => __( 'Enable avertising on pages', THEME_TEXTDOMAIN ),
                    'type'  => 'checkbox',
                ],

                'microdata_publisher_telephone' => [
                    'label'       => __( 'The value of the telephone field for publisher microdata', THEME_TEXTDOMAIN ),
                    'description' => __( 'If the field is not specified, the site name will be displayed as the telephone value', THEME_TEXTDOMAIN ),
                ],

                'microdata_publisher_address' => [
                    'label'       => __( 'The value of the address field for publisher microdata', THEME_TEXTDOMAIN ),
                    'description' => __( 'If the field is not specified, the site address will be displayed as the address value', THEME_TEXTDOMAIN ),
                ],

            ]
        ],


        'partner' => [
            'title'       => __( 'Affiliate program', THEME_TEXTDOMAIN ),
            'description' => 'Мы добавили возможность зарабатывать Вам на нашей <a href="https://wpshop.ru/partner" target="_blank" rel="noopener">партнерской программе</a>. Вы можете встроить партнерскую ссылку в подвал сайта и зарабатывать 25% с продаж. Ваш партнерский ID уже встроен в тему.<br><br>Ссылка замаскирована через JS, она не индексируется и не передает вес страницы и обернута в noindex.<br><br>О продаже по партнерской ссылке мы сообщим Вам на e-mail, Вы ничего не пропустите.',
            'priority'    => 999,

            'controls' => [

                'wpshop_partner_enable' => [
                    'label' => __( 'Start earning money', THEME_TEXTDOMAIN ),
                    'type'  => 'checkbox',
                ],

                'wpshop_partner_prefix' => [
                    'label' => __( 'Text before link', THEME_TEXTDOMAIN ),
                ],

                'wpshop_partner_postfix' => [
                    'label' => __( 'Text after link', THEME_TEXTDOMAIN ),
                ],

            ],
        ],
    ];

    // apply filter
    $customizer_controls = apply_filters( 'wpshop_customizer_controls', $customizer_controls );

    // set defaults
    $wpshop_customizer->set_defaults( $wpshop_core->get_default_options() );

    // add controls
    $wpshop_customizer->add_controls( $customizer_controls );

    // init
    $wpshop_customizer->init( $wp_customize );

} );



/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function wpshop_customize_register( $wp_customize ) {
    $wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
    $wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
    $wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

    if ( isset( $wp_customize->selective_refresh ) ) {
        $wp_customize->selective_refresh->add_partial( 'blogname', [
            'selector'        => '.site-title a',
            'render_callback' => 'wpshop_customize_partial_blogname',
        ] );
        $wp_customize->selective_refresh->add_partial( 'blogdescription', [
            'selector'        => '.site-description',
            'render_callback' => 'wpshop_customize_partial_blogdescription',
        ] );
    }
}
//add_action( 'customize_register', 'wpshop_customize_register' );



/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function wpshop_customize_partial_blogname() {
    bloginfo( 'name' );
}



/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function wpshop_customize_partial_blogdescription() {
    bloginfo( 'description' );
}



function wpshop_customizer_body_classes( $classes ) {

    global $wpshop_core;

    /********************************************************************
     * Sidebar
     */

    $sidebar_class = '';

    // Сайдбар записи
    if ( ! $wpshop_core->get_option( 'structure_single_sidebar' ) && is_single() ) {
        $sidebar_class = 'sidebar-none';
    }

    // Сайдбар страниц
    if ( ! $wpshop_core->get_option( 'structure_page_sidebar' ) && is_page() ) {
        $sidebar_class = 'sidebar-none';
    }

    // настройки для отдельной статьи
    if ( is_single() || is_page() ) {
        global $wpshop_core;

        if ( ! $wpshop_core->is_show_element( 'sidebar' ) ) {
            $sidebar_class = 'sidebar-none';
        }
    }

    $classes[] = $sidebar_class;

    return $classes;
}
add_filter( 'body_class', 'wpshop_customizer_body_classes' );



/**
 * Customizer CSS
 */
require get_template_directory() . '/inc/customizer/customizer-css.php';