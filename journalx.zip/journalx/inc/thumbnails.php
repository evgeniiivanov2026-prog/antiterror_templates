<?php
/**
 * ****************************************************************************
 *
 *   НЕ РЕДАКТИРУЙТЕ ЭТОТ ФАЙЛ
 *   DON'T EDIT THIS FILE
 *
 * *****************************************************************************
 *
 * @package journalx
 */

function wpshop_core_thumbnails() {

    class Posts_Thumbnails extends Wpshop\Core\MetaBox {

        public function __construct() {
            $this->set_settings( [
                'prefix'         => 'posts_thumb_',
                'post_type'      => apply_filters( THEME_SLUG . '_metabox_thumbnail_post_type', [ 'post', 'page' ] ),
                'meta_box_title' => __( 'Thumbnails settings', THEME_TEXTDOMAIN ),
                'context'        => 'side',
            ] );

            parent::__construct();
        }

        public function render_fields() {
            $field_text  = '';
            $field_text .= '<p><strong>' . __( 'Recommended sizes', THEME_TEXTDOMAIN ) . '</strong></p>';
            $field_text .= '<p>';
            $field_text .= sprintf( esc_html__( 'Standard: %s', THEME_TEXTDOMAIN ), '700x400' ) . '<br>';
            $field_text .= sprintf( esc_html__( 'Wide: %s', THEME_TEXTDOMAIN ), '1200x500' ) . '<br>';
            $field_text .= sprintf( esc_html__( 'Full width: %s', THEME_TEXTDOMAIN ), '1920x500' ) . '<br>';
            $field_text .= '</p>';

            echo $field_text;

            $this->field_select( 'thumbnail_size', __( 'The size of the thumbnail in the post', THEME_TEXTDOMAIN ), [
                'standard' => __( 'Standard', THEME_TEXTDOMAIN ),
                'wide'     => __( 'Wide', THEME_TEXTDOMAIN ),
                'full'     => __( 'Full width', THEME_TEXTDOMAIN ),
                'no'       => __( 'Do not show', THEME_TEXTDOMAIN ),
            ] );

            $this->field_select( 'post_card_size', __( 'Post card', THEME_TEXTDOMAIN ), [
                'standard' => __( 'Standard', THEME_TEXTDOMAIN ),
                'card'     => __( 'Horizontal', THEME_TEXTDOMAIN ),
                'wide'     => __( 'Wide', THEME_TEXTDOMAIN ),
                'high'     => __( 'High', THEME_TEXTDOMAIN ),
                'big'      => __( 'Large', THEME_TEXTDOMAIN ),
            ] );

            $this->field_checkbox( 'thumbnail_caption', __( 'Show thumbnail caption', THEME_TEXTDOMAIN ) );
        }

    }

    new Posts_Thumbnails;

}
add_action( 'after_setup_theme', 'wpshop_core_thumbnails' );