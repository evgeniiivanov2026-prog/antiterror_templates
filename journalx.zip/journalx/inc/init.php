<?php
/**
 * ****************************************************************************
 *
 *   НЕ РЕДАКТИРУЙТЕ ЭТОТ ФАЙЛ
 *   DON'T EDIT THIS FILE
 *
 * *****************************************************************************
 *
 * @package journalx
 */


/**
 * Theme config
 */
require get_template_directory() . '/inc/config.php';


/**
 * Enqueue styles and scripts
 */
require get_template_directory() . '/inc/enqueue.php';


/**
 * Google captcha support
 */
require get_template_directory() . '/inc/google-captcha-support.php';


/**
 * Core
 */
require get_template_directory() . '/inc/core.php';


/**
 * Default options
 */
require get_template_directory() . '/inc/default-options.php';


/**
 * after_setup_theme hooks: widgets, menus, theme_support
 */
require get_template_directory() . '/inc/setup.php';


/**
 * Upgrade
 */
require get_template_directory() . '/inc/upgrade.php';


/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer/customizer.php';


/**
 * TinyMCE
 */
if ( is_admin() ) {
    require get_template_directory() . '/inc/tinymce.php';
}


/**
 * Metaboxes
 */
require get_template_directory() . '/inc/meta-boxes.php';


/**
 * Scroll
 */
require get_template_directory() . '/inc/class-scroll.php';
$class_scroll = new Scroll();
$class_scroll->init();


/**
 * Ajax Comments
 */
require get_template_directory() . '/inc/journalx-comments.php';


/**
 * Comments
 */
require get_template_directory() . '/inc/comments.php';


/**
 * Thumbnails
 */
require get_template_directory() . '/inc/thumbnails.php';


/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';


/**
 * Post card
 */
require get_template_directory() . '/inc/post-card.php';


/**
 * Shortcodes
 */
require get_template_directory() . '/inc/shortcodes.php';


/**
 * Widgets
 */
require get_template_directory() . '/inc/widgets/widgets.php';


/**
 * WPShop Partner ID
 */
require get_template_directory() . '/inc/partner-id.php';
