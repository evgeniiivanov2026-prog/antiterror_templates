<?php
/**
 * ****************************************************************************
 *
 *   НЕ РЕДАКТИРУЙТЕ ЭТОТ ФАЙЛ
 *   DON'T EDIT THIS FILE
 *
 * *****************************************************************************
 *
 * @package journalx
 */

if ( ! function_exists( 'wpshop_theme_setup' ) ) :
    function wpshop_theme_setup() {

        // Add default posts and comments RSS feed links to head.
        if ( apply_filters( THEME_SLUG . '_allow_rss_links', false ) ) {
            add_theme_support( 'automatic-feed-links' );
        }


        // Let WordPress manage the document title.
        add_theme_support( 'title-tag' );


        // Switch default core markup to output valid HTML5.
        add_theme_support( 'html5', array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
        ) );


        // Enable support for Post Thumbnails on posts and pages.
        add_theme_support( 'post-thumbnails' );
        $thumb_big_sizes  = apply_filters( THEME_SLUG . '_thumb_big_sizes', array( 700, 400, true ) );
        $thumb_wide_sizes = apply_filters( THEME_SLUG .  '_thumb_wide_sizes', array( 350, 200, true ) );
        $thumb_small_sizes = apply_filters( THEME_SLUG . '_thumb_small_sizes', array( 180, 100, true ) );
        if ( function_exists( 'add_image_size' ) ) {
            add_image_size( 'thumb-big', $thumb_big_sizes[0], $thumb_big_sizes[1], $thumb_big_sizes[2]);
            add_image_size( 'thumb-wide', $thumb_wide_sizes[0], $thumb_wide_sizes[1], $thumb_wide_sizes[2] );
            add_image_size( 'thumb-small', $thumb_small_sizes[0], $thumb_small_sizes[1], $thumb_small_sizes[2] );
        }


        // Set up the WordPress core custom background feature.
        add_theme_support( 'custom-background', apply_filters( THEME_SLUG . '_custom_background_args', array(
            'default-color' => 'ffffff',
            'default-image' => '',
        ) ) );


        // This theme uses wp_nav_menu() in one location.
        register_nav_menus( array(
            'header_menu' => esc_html__( 'Header menu', THEME_TEXTDOMAIN ),
            'footer_menu' => esc_html__( 'Footer menu', THEME_TEXTDOMAIN ),
        ) );


        // Add support selective refresh for widgets in customize.
        add_theme_support( 'customize-selective-refresh-widgets' );

    }

endif;
add_action( 'after_setup_theme', 'wpshop_theme_setup' );



/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function wpshop_content_width() {
    $GLOBALS['content_width'] = apply_filters( THEME_SLUG . '_content_width', 640 );
}
add_action( 'after_setup_theme', 'wpshop_content_width', 0 );



/**
 * Register widget area.
 *
 */
function wpshop_widgets_init() {
    register_sidebar( array(
        'name'          => esc_html__( 'Sidebar', THEME_TEXTDOMAIN ),
        'id'            => 'sidebar-1',
        'description'   => esc_html__( 'Add widgets here.', THEME_TEXTDOMAIN ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<div class="widget-header">',
        'after_title'   => '</div>',
    ) );
}
add_action( 'widgets_init', 'wpshop_widgets_init' );



/**
 * Body background link
 */
global $wpshop_core;

$wpshop_body_bg_link    = $wpshop_core->get_option( 'body_bg_link' );
$wpshop_body_bg_link_js = $wpshop_core->get_option( 'body_bg_link_js' );

if ( ! empty( $wpshop_body_bg_link ) ) {
    add_action( 'journalx_after_body', function() {
        global $wpshop_body_bg_link;
        global $wpshop_body_bg_link_js;

        echo '<div style="position:fixed; overflow:hidden; top:0px; left:0px; width:100%; height:100%;">';

        if ( $wpshop_body_bg_link_js ) {
            echo '<span class="js-link" data-href="' . base64_encode( $wpshop_body_bg_link ) . '" data-target="_blank" style="display:block; height:100%; width:100%;"></span>';
        } else {
            echo '<a href="' . $wpshop_body_bg_link . '" target="_blank" style="display:block; height:100%; width:100%;"></a>';
        }

        echo '</div>';

    } );
}



/**
 * Fixed header
 */
global $wpshop_core;

if ( $wpshop_core->get_option( 'header_fixed' ) ) {
    add_action( 'wp_head', function () {
        echo "<script>var fixed_header = 'yes';</script>";
    } );
}



/**
 * Breadcrumbs home text
 */
add_filter( 'wpshop_breadcrumbs_home_text', function ( $title ) {
    global $wpshop_core;
    if ( $new_title = $wpshop_core->get_option( 'breadcrumbs_home_text' ) ) {
        return $new_title;
    }

    return $title;
} );



/**
 * Breadcrumbs single link
 */
$breadcrumbs_single_link = $wpshop_core->get_option( 'breadcrumbs_single_link' );
if ( $breadcrumbs_single_link ) {
    add_filter( 'wpshop_breadcrumb_single_link', '__return_true' );
}



/**
 * TOC
 */
$toc_noindex = $wpshop_core->get_option( 'toc_noindex' );
if ( $toc_noindex ) {
    add_filter( 'wpshop_toc_noindex', '__return_true' );
}

$toc_open = $wpshop_core->get_option( 'toc_open' );
if ( ! $toc_open ) {
    add_filter( 'wpshop_toc_open', '__return_false' );
}

$toc_display = $wpshop_core->get_option( 'toc_display' );
$toc_display_pages = $wpshop_core->get_option( 'toc_display_pages' );

if ( $toc_display ) {
    add_filter( 'wpshop_toc_in_single', '__return_true' );
} else {
    add_filter( 'wpshop_toc_in_single', '__return_false' );
}

if ( $toc_display_pages ) {
    add_filter( 'wpshop_toc_in_page', '__return_true' );
} else {
    add_filter( 'wpshop_toc_in_page', '__return_false' );
}

$toc_place = $wpshop_core->get_option( 'toc_place' );
if ( $toc_place ) {
    add_filter( 'wpshop_toc_place', '__return_false' );
}

add_filter( 'wpshop_toc_header', function ( $title ) {
    global $wpshop_core;
    if ( $new_title = $wpshop_core->get_option( 'toc_title' ) ) {
        return $new_title;
    }

    return $title;
} );



if ( $toc_display || $toc_display_pages ) {
    global $wpshop_table_of_contents;
    $wpshop_table_of_contents->init();
}



/**
 * Show comment time
 */
$comments_time = $wpshop_core->get_option( 'comments_time' );
if ( ! $comments_time ) {
    add_filter( 'journalx_comments_show_time', '__return_false' );
}



/**
 * Search page title with results
 */
add_filter( 'journalx_search_with_results_title', function ( $title ) {
    global $wpshop_core;
    if ( $new_title = $wpshop_core->get_option( 'structure_search_with_results_title' ) ) {
        return $new_title;
    }

    return $title;
} );



/**
 * Search page title without results
 */
add_filter( 'journalx_search_without_results_title', function ( $title ) {
    global $wpshop_core;
    if ( $new_title = $wpshop_core->get_option( 'structure_search_without_results_title' ) ) {
        return $new_title;
    }

    return $title;
} );



/**
 * Search page text without results
 */
add_filter( 'journalx_search_without_results_text', function ( $title ) {
    global $wpshop_core;
    if ( $new_title = $wpshop_core->get_option( 'structure_search_without_results_text' ) ) {
        return $new_title;
    }

    return $title;
} );



/**
 * 404 page title
 */
add_filter( 'journalx_404_title', function ( $title ) {
    global $wpshop_core;
    if ( $new_title = $wpshop_core->get_option( 'structure_404_title' ) ) {
        return $new_title;
    }

    return $title;
} );



/**
 * 404 page text
 */
add_filter( 'journalx_404_text', function ( $title ) {
    global $wpshop_core;
    if ( $new_title = $wpshop_core->get_option( 'structure_404_text' ) ) {
        return $new_title;
    }

    return $title;
} );



/**
 * Author social title
 */
add_filter( 'journalx_author_social_title', function ( $title ) {
    global $wpshop_core;
    if ( $new_title = $wpshop_core->get_option( 'author_social_title' ) ) {
        return $new_title;
    }

    return $title;
} );



/**
 * Exclude category in sitemap
 */
add_filter( 'wpshop_sitemap_category_exclude', function() {
    global $wpshop_core;
    $sitemap_category_exclude = $wpshop_core->get_option( 'sitemap_category_exclude' );

    if ( ! empty( $sitemap_category_exclude ) ) {
        $sitemap_category_exclude_id = explode( ',', $sitemap_category_exclude );

        if ( is_array( $sitemap_category_exclude_id ) ) {
            $sitemap_category_exclude = array_map( 'trim', $sitemap_category_exclude_id );
        } else {
            $sitemap_category_exclude = array( $sitemap_category_exclude );
        }
    }

    return $sitemap_category_exclude;
} );



/**
 * Exclude posts in sitemap
 */
add_filter( 'wpshop_sitemap_posts_exclude', function() {
    global $wpshop_core;
    $sitemap_posts_exclude = $wpshop_core->get_option( 'sitemap_posts_exclude' );

    if ( ! empty( $sitemap_posts_exclude ) ) {
        $sitemap_posts_exclude_id = explode( ',', $sitemap_posts_exclude );

        if ( is_array( $sitemap_posts_exclude_id ) ) {
            $sitemap_posts_exclude = array_map( 'trim', $sitemap_posts_exclude_id );
        } else {
            $sitemap_posts_exclude = array( $sitemap_posts_exclude );
        }
    }

    return $sitemap_posts_exclude;
} );



/**
 * Show pages in sitemap
 */
$sitemap_pages_show = $wpshop_core->get_option( 'sitemap_pages_show' );
if ( ! $sitemap_pages_show ) {
    add_filter( 'wpshop_sitemap_show_pages', '__return_false' );
}



/**
 * Exclude pages in sitemap
 */
add_filter( 'wpshop_sitemap_pages_exclude', function() {
    global $wpshop_core;
    $sitemap_pages_exclude = $wpshop_core->get_option( 'sitemap_pages_exclude' );

    if ( ! empty( $sitemap_pages_exclude ) ) {
        $sitemap_pages_exclude_id = explode( ',', $sitemap_pages_exclude );

        if ( is_array( $sitemap_pages_exclude_id ) ) {
            $sitemap_pages_exclude = array_map( 'trim', $sitemap_pages_exclude_id );
        } else {
            $sitemap_pages_exclude = array( $sitemap_pages_exclude );
        }
    }

    return $sitemap_pages_exclude;
} );



/**
 * Related posts title
 */
add_filter( 'journalx_related_title', function ( $title ) {
    global $wpshop_core;
    if ( $new_title = $wpshop_core->get_option( 'related_posts_title' ) ) {
        return $new_title;
    }

    return $title;
} );



/**
 * Views counter
 */
global $wpshop_views_counter;
$wpshop_views_counter->init();



/**
 * Show title author social
 */
$author_social_title_show = $wpshop_core->get_option( 'author_social_title_show' );
if ( ! $author_social_title_show ) {
    add_filter( 'journalx_author_social_title_show', '__return_false' );
}



/**
 * Social buttons title
 */
add_filter( 'journalx_social_share_title', function ( $title ) {
    global $wpshop_core;
    if ( $new_title = $wpshop_core->get_option( 'social_share_title' ) ) {
        return $new_title;
    }

    return $title;
} );



/**
 * Show title social buttons
 */
$social_share_title_show = $wpshop_core->get_option( 'social_share_title_show' );
if ( ! $social_share_title_show ) {
    add_filter( 'journalx_social_share_title_show', '__return_false' );
}



/**
 * Rating title
 */
add_filter( 'journalx_rating_title', function ( $title ) {
    global $wpshop_core;
    if ( $new_title = $wpshop_core->get_option( 'rating_title' ) ) {
        return $new_title;
    }

    return $title;
} );



/**
 * Rating text
 */
$rating_text_show = $wpshop_core->get_option( 'rating_text_show' );
if ( ! $rating_text_show ) {
    add_filter( 'journalx_rating_text_show', '__return_false' );
}



/**
 * Enable advertising on pages
 */
$advertising_page_display = $wpshop_core->get_option( 'advertising_page_display' );
if ( $advertising_page_display ) {
    add_filter( 'wpshop_advertising_single', '__return_false' );
}



/**
 * Microdata publisher telephone
 */
$microdata_publisher_telephone = $wpshop_core->get_option( 'microdata_publisher_telephone' );
if ( ! empty( $microdata_publisher_telephone ) ) {
    add_filter( 'wpshop_microdata_publisher_telephone', 'microdata_publisher_telephone_change' );
}
function microdata_publisher_telephone_change() {
    global $wpshop_core;
    $microdata_publisher_telephone = $wpshop_core->get_option( 'microdata_publisher_telephone' );
    return $microdata_publisher_telephone;
}



/**
 * Microdata publisher address
 */
$microdata_publisher_address = $wpshop_core->get_option( 'microdata_publisher_address' );
if ( ! empty( $microdata_publisher_address ) ) {
    add_filter( 'wpshop_microdata_publisher_address', 'microdata_publisher_address_change' );
}
function microdata_publisher_address_change() {
    global $wpshop_core;
    $microdata_publisher_address = $wpshop_core->get_option( 'microdata_publisher_address' );
    return $microdata_publisher_address;
}
