<?php

function content_aside( $atts , $content = null ) {

    // Attributes
    $atts = shortcode_atts( array(
        'id'     => '',
        'text'   => '',
        'target' => '',
    ), $atts, 'content-aside' );

    $post_out = '';

    if ( ! empty( $atts['id'] ) ) {

        if ( ! empty( $atts['text'] ) ) {
            $link_text = $atts['text'];
        } else {
            $link_text = get_the_title( $atts['id'] );
        }

        $thumb = get_the_post_thumbnail( $atts['id'], 'thumb-small' );
        $post_out = '<div class="content-post"><a href="' . get_the_permalink( $atts['id'] ) . '" target="' . $atts['target'] . '">' . $thumb . $link_text . '</a></div>';
    }

    return '<aside class="content-right">' . $post_out . do_shortcode( $content ) . '</aside>';

}
add_shortcode( 'content-aside', 'content_aside' );




function content_wide( $atts , $content = null ) {

    return '<aside class="content-wide">' . do_shortcode( $content ) . '</aside>';

}
add_shortcode( 'content-wide', 'content_wide' );



function content_post( $atts, $content = null ) {

    $atts = shortcode_atts(
        array(
            'post_id' => '',
        ),
        $atts,
        'content-aside'
    );

    return '<aside class="content-wide">' . do_shortcode( $content ) . '</aside>';
}