<?php

class Wpshop_Upgrade {

    private $db_version;

    public function __construct() {

        $this->db_version = get_option( 'theme_' . THEME_SLUG . '_version', '' );

        if ( version_compare( $this->db_version, THEME_ORIGINAL_VERSION, '<' ) ) {
            if ( function_exists( 'opcache_reset' ) ) {
                @opcache_reset();
            }

            $this->upgrade();
            $this->finish_up();
        }
    }


    /**
     * Upgrade function
     */
    public function upgrade() {

        if ( version_compare( $this->db_version, '1.2', '<' ) ) {
            $this->upgrade_12();
        }

    }

    /**
     * Perform the 1.2 upgrade.
     *
     * @return void
     */
    private function upgrade_12() {
        global $wpshop_core;

        if ( $social_vk = $wpshop_core->get_option( 'social_vk' ) ) {
            $wpshop_core->set_option( 'social_vkontakte', $social_vk );
        }

        if ( $social_ok = $wpshop_core->get_option( 'social_ok' ) ) {
            $wpshop_core->set_option( 'social_odnoklassniki', $social_ok );
        }

    }


    /**
     * Update version in db and flush rewrite rules
     */
    protected function finish_up() {
        update_option( 'theme_' . THEME_SLUG . '_version', THEME_ORIGINAL_VERSION );
        //add_action( 'shutdown', 'flush_rewrite_rules' );                     // Just flush rewrites, always, to at least make them work after an upgrade.
    }
}
new Wpshop_Upgrade();