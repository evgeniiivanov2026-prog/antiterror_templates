<?php
/**
 * ****************************************************************************
 *
 *   НЕ РЕДАКТИРУЙТЕ ЭТОТ ФАЙЛ
 *   DON'T EDIT THIS FILE
 *
 *   Используйте хук {THEME_SLUG}_options_defaults
 *   Use hook {THEME_SLUG}_options_defaults
 *
 * *****************************************************************************
 *
 * @package journalx
 */

$default_options = apply_filters( THEME_SLUG . '_options_defaults', [

    // layout  >  header
    'header_width'                           => 'fixed',
    'header_padding_top'                     => 0,
    'header_padding_bottom'                  => 0,
    'header_fixed'                           => false,

    // layout  >  footer
    'footer_width'                           => 'fixed',


    // blocks  >  header
    'logotype_image'                         => '',
    'logotype_max_width'                     => 1000,
    'logotype_max_height'                    => 100,
    'header_hide_title'                      => false,
    'header_social'                          => true,
    'header_html_block_1'                    => '',
    'header_html_block_2'                    => '',
    'header_search'                          => true,

    // blocks  >  footer
    'footer_copyright'                       => '© %year% ' . get_bloginfo( 'name' ),
    'footer_social'                          => true,
    'footer_html_block_1'                    => '',
    'footer_html_block_2'                    => '',
    'footer_counters'                        => '',

    // blocks  >  home
    'structure_home_h1'                      => '',
    'structure_home_text'                    => '',
    'structure_home_position'                => 'bottom',

    // blocks  >  single
    'structure_single_sidebar'               => true,
    'structure_single_hide'                  => 'author,author_box',
    'structure_single_related'               => 8,

    // blocks  >  page
    'structure_page_sidebar'                 => true,
    'structure_page_hide'                    => '',
    'structure_page_related'                 => 8,

    // blocks  >  archive
    'structure_archive_description_show'     => true,
    'structure_archive_subcategories'        => true,
    'structure_archive_description'          => 'top',

    // blocks  >  comments
    'comments_text_before_submit'            => '',
    'comments_date'                          => true,
    'comments_time'                          => true,
    'comments_output'                        => false,

    // blocks  >  search
    'structure_search_with_results_title'    => __( 'Search results for', THEME_TEXTDOMAIN ),
    'structure_search_without_results_title' => __( 'Nothing found', THEME_TEXTDOMAIN ),
    'structure_search_without_results_text'  => __( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', THEME_TEXTDOMAIN ),
    'structure_search_form_show'             => true,
    'structure_search_related_show'          => true,

    // blocks  >  404
    'structure_404_title'                    => __( 'Oops! That page can&rsquo;t be found.', THEME_TEXTDOMAIN ),
    'structure_404_text'                     => __( 'It looks like nothing was found at this location. Try one of the links below or use a search.', THEME_TEXTDOMAIN ),
    'structure_404_search_form_show'         => true,
    'structure_404_related_show'             => true,


    // modules  >  toc
    'toc_display'                            => false,
    'toc_display_pages'                      => false,
    'toc_open'                               => true,
    'toc_noindex'                            => false,
    'toc_place'                              => false,
    'toc_title'                              => __( 'Contents', THEME_TEXTDOMAIN ),

    // modules  >  lightbox
    'lightbox_display'                       => false,

    // modules  >  breadcrumbs
    'breadcrumbs_display'                    => true,
    'breadcrumbs_home_text'                  => __( 'Home', THEME_TEXTDOMAIN ),
    'breadcrumbs_archive'                    => true,
    'breadcrumbs_single_link'                => false,

    // modules  >  author block
    'author_link'                            => false,
    'author_link_target'                     => false,
    'author_social_enable'                   => false,
    'author_social_title'                    => __( 'Author profiles', THEME_TEXTDOMAIN ),
    'author_social_title_show'               => true,
    'author_social_js'                       => true,

    // modules  >  contact form
    'contact_form_text_before_submit'        => '',

    // modules  >  social profiles
    'social_facebook'                        => '',
    'social_vkontakte'                       => '',
    'social_twitter'                         => '',
    'social_odnoklassniki'                   => '',
    'social_telegram'                        => '',
    'social_youtube'                         => '',
    'social_instagram'                       => '',
    'social_linkedin'                        => '',
    'social_whatsapp'                        => '',
    'social_viber'                           => '',
    'social_pinterest'                       => '',
    'social_yandexzen'                       => '',
    'social_github'                          => '',
    'social_discord'                         => '',
    'social_rutube'                          => '',
    'social_yappy'                           => '',
    'social_pikabu'                          => '',
    'social_yandex'                          => '',
    'structure_social_js'                    => true,

    // modules > share buttons
    'share_buttons'                          => 'vkontakte,facebook,telegram,odnoklassniki,twitter,sms,viber,whatsapp',
    'share_buttons_counters'                 => false,

    // modules  >  sitemap
    'sitemap_category_exclude'               => '',
    'sitemap_posts_exclude'                  => '',
    'sitemap_pages_show'                     => true,
    'sitemap_pages_exclude'                  => '',

    // modules  >  related posts
    'related_posts_title'                    => __( 'Related articles', THEME_TEXTDOMAIN ),
    'related_post_taxonomy_order'            => 'categories',
    'related_posts_exclude'                  => '',
    'related_posts_category_exclude'         => '',

    // modules  >  scroll to top
    'structure_arrow'                        => true,
    'structure_arrow_mob'                    => false,
    'structure_arrow_bg'                     => '#ffffff',
    'structure_arrow_color'                  => '#305cf7',
    'structure_arrow_width'                  => '60',
    'structure_arrow_height'                 => '50',
    'structure_arrow_position'               => 'right',
    'structure_arrow_icon'                   => '\2b9d',

    // modules > views counter
    'wpshop_views_counter_enable'            => true,
    'wpshop_views_counter_to_count'          => '0',
    'wpshop_views_counter_exclude_bots'      => '1',


    // post card  >  main
    'structure_posts_tag'                    => 'div',
    'post_card_main_order'                   => 'thumbnail,category,title',
    'post_card_main_order_meta'              => 'date,comments_number,views',
    'post_card_main_excerpt_length'          => 50,

    // post card  >  related
    'structure_posts_related_tag'            => 'h2',
    'post_card_related_order'                => 'thumbnail,title',
    'post_card_related_order_meta'           => 'comments_number,views',
    'post_card_related_excerpt_length'       => 50,


    // codes
    'code_head'                              => '',
    'code_body'                              => '',
    'code_after_content'                     => '',


    // infinity scroll
    'infinity_scroll_archive_enabled'        => true,
    'infinity_scroll_archive_limit'          => 10,
    'infinity_scroll_single_enabled'         => true,
    'infinity_scroll_single_category'        => false,
    'infinity_scroll_single_limit'           => 10,
    'loaded_content_height'                  => 0,
    'yandex_metrika_id'                      => '',
    'ga_tracking_id'                         => '',


    // typography  >  general
    'typography_body'                        => json_encode( [
        'font-family'                        => 'times_serif',
        'font-size'                          => '18',
        'line-height'                        => '1.5',
        'font-style'                         => '',
        'unit'                               => 'px'
    ] ),

    // typography  >  header
    'typography_site_title'                  => json_encode( [
        'font-family'                        => 'roboto',
        'font-size'                          => '29',
        'line-height'                        => '1.1',
        'font-style'                         => '',
        'unit'                               => 'px'
    ] ),

    'typography_site_description'            => json_encode( [
        'font-family'                        => 'roboto',
        'font-size'                          => '16',
        'line-height'                        => '1.5',
        'font-style'                         => '',
        'unit'                               => 'px'
    ] ),

    // typography  >  menu
    'typography_menu_links'                  => json_encode( [
        'font-family'                        => 'roboto',
        'font-size'                          => '15',
        'line-height'                        => '1.5',
        'font-style'                         => '',
        'unit'                               => 'px'
    ] ),

    // typography  >  headers
    'typography_header_h1'                   => json_encode( [
        'font-family'                        => 'montserrat',
        'font-size'                          => '2.4',
        'font-style'                         => '',
        'line-height'                        => '1.5',
        'unit'                               => 'em'
    ] ),

    'typography_header_h2'                   => json_encode( [
        'font-family'                        => 'montserrat',
        'font-size'                          => '1.9',
        'font-style'                         => '',
        'line-height'                        => '1.2',
        'unit'                               => 'em'
    ] ),

    'typography_header_h3'                   => json_encode( [
        'font-family'                        => 'montserrat',
        'font-size'                          => '1.6',
        'font-style'                         => '',
        'line-height'                        => '1.3',
        'unit'                               => 'em'
    ] ),

    'typography_header_h4'                   => json_encode( [
        'font-family'                        => 'montserrat',
        'font-size'                          => '1.25',
        'font-style'                         => '',
        'line-height'                        => '1.4',
        'unit'                               => 'em'
    ] ),

    'typography_header_h5'                   => json_encode( [
        'font-family'                        => 'montserrat',
        'font-size'                          => '1',
        'font-style'                         => '',
        'line-height'                        => '1.5',
        'unit'                               => 'em'
    ] ),

    'typography_header_h6'                   => json_encode( [
        'font-family'                        => 'montserrat',
        'font-size'                          => '.75',
        'font-style'                         => '',
        'line-height'                        => '2',
        'unit'                               => 'em'
    ] ),


    // colors
    'color_main'                             => '#305cf7',
    'color_text'                             => '#222222',
    'color_link'                             => '#222222',
    'color_link_hover'                       => '#305cf7',
    'color_header_bg'                        => '#ffffff',
    'color_logo'                             => '#000000',
    'color_site_description'                 => '#111111',
    'color_menu'                             => '#222222',
    'color_footer_bg'                        => '#eeeeee',

    // background
    'body_bg_link'                           => '',
    'body_bg_link_js'                        => true,
    'header_bg'                              => '',
    'header_bg_repeat'                       => 'no-repeat',
    'header_bg_position'                     => 'center center',
    'header_bg_mob'                          => false,


    // tweak
    'social_share_title'                     => __( 'Share:', THEME_TEXTDOMAIN ),
    'social_share_title_show'                => true,
    'rating_title'                           => __( 'Rating', THEME_TEXTDOMAIN ),
    'rating_text_show'                       => true,
    'advertising_page_display'               => false,
    'microdata_publisher_telephone'          => '',
    'microdata_publisher_address'            => '',


    // partner program
    'wpshop_partner_enable'                  => false,
    'wpshop_partner_prefix'                  => __( 'Powered by theme', THEME_TEXTDOMAIN ),
    'wpshop_partner_postfix'                 => '',

] );


/**
 * Set default options
 */
global $wpshop_core;
$wpshop_core->set_default_options( $default_options );
