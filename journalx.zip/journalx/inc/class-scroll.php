<?php

class Scroll {

    private $debug = false;

    public function __construct() {

    }

    public function init() {
        add_action( 'wp_ajax_nopriv_journalx_load_post', array( $this, 'journalx_load_post_handler' ) );
        add_action( 'wp_ajax_journalx_load_post', array( $this, 'journalx_load_post_handler' ) );

        add_action( 'wp_ajax_nopriv_journalx_load_posts', array( $this, 'journalx_load_posts_handler' ) );
        add_action( 'wp_ajax_journalx_load_posts', array( $this, 'journalx_load_posts_handler' ) );

        add_action( 'wp_footer', array( $this, 'single_scroll_settings' ) );

        add_action( 'journalx/scroll/output', [ $this, '_add_wpremark_support' ] );
    }

    public function single_scroll_settings() {
        if ( ! is_single() ) return;

        global $wpshop_core;

        $infinity_scroll_single_enabled = $wpshop_core->get_option( 'infinity_scroll_single_enabled' );
        if ( $infinity_scroll_single_enabled ) {
            $infinity_scroll_single_enabled = 'true';
        } else {
            $infinity_scroll_single_enabled = 'false';
        }

        $infinity_scroll_single_limit = $wpshop_core->get_option( 'infinity_scroll_single_limit' );
        if ( empty( $infinity_scroll_single_limit ) ) $infinity_scroll_single_limit = 10;

        $yandex_metrika_id = $wpshop_core->get_option( 'yandex_metrika_id' );
        $ga_tracking_id = $wpshop_core->get_option( 'ga_tracking_id' );

        echo '<script>';
        if ( ! empty( $yandex_metrika_id ) ) echo 'var yandex_counter = window.yaCounter' . $yandex_metrika_id . ';';
        if ( ! empty( $ga_tracking_id ) ) echo 'var ga_tracking_id = "'. $ga_tracking_id . '";';
        echo 'var infinity_scroll_single_enabled = ' . $infinity_scroll_single_enabled . ';';
        echo 'var infinity_scroll_single_limit = ' . $infinity_scroll_single_limit . ';';
        echo '</script>';
    }

    public function infinity_scroll_holder() {

        if ( $GLOBALS['wp_query']->max_num_pages > 1 ) {

            $paged = get_query_var( 'paged', '1' );
            $paged = ( ! empty( $paged ) ) ? $paged : 1;

            $query_vars = $GLOBALS['wp_query']->query_vars;

            global $wpshop_core;
            $infinity_scroll_archive_enabled = $wpshop_core->get_option( 'infinity_scroll_archive_enabled' );
            $infinity_scroll_archive_limit = $wpshop_core->get_option( 'infinity_scroll_archive_limit' );
            if ( empty( $infinity_scroll_archive_limit ) ) $infinity_scroll_archive_limit = 10;

            if ( $infinity_scroll_archive_enabled ) {
                echo '<div class="js-infinity-scroll"></div>';
                echo '<script>';
                echo 'var query_vars = "' . base64_encode( json_encode( $query_vars ) ) . '";';
                echo 'var current_page = ' . $paged . ';';
                echo 'var max_pages = ' . $GLOBALS['wp_query']->max_num_pages . ';';
                echo 'var infinity_scroll_archive_limit = ' . $infinity_scroll_archive_limit . ';';
                echo '</script>';
            }

        } else {
            if ( $this->debug ) echo '<!-- just 1 page -->';
        }
    }

    public function journalx_load_posts_handler() {

//        $nonce = $_POST['nonce'];
//
//        // проверяем nonce код, если проверка не пройдена прерываем обработку
//        if ( ! wp_verify_nonce( $nonce, 'wpshop-nonce' ) ) {
//            die( __( 'Please, refresh page', THEME_TEXTDOMAIN ) );
//        }

        // получаем ID текущего поста
        $current_page = (int) $_POST['current_page'];
        $query_vars = $_POST['query_vars'];

        $query_vars = json_decode( base64_decode( $query_vars ), true );
        $query_vars['paged'] = $current_page + 1;
        $query_vars['post_status'] = 'publish';

        query_posts( $query_vars );

        if ( have_posts() ) {

            while ( have_posts() ): the_post();

                get_template_part( 'template/content', get_post_format() );

            endwhile;

        }

        die();

    }



    public function journalx_load_post_handler() {

        $nonce = $_POST['nonce'];

        // проверяем nonce код, если проверка не пройдена прерываем обработку
        if ( ! wp_verify_nonce( $nonce, 'wpshop-nonce' ) ) {
            die( 'Stop!' );
        }

        global $wpshop_core;

        $infinity_scroll_single_category = $wpshop_core->get_option( 'infinity_scroll_single_category' );

        // получаем ID текущего поста
        $post_id = (int) $_POST['post_id'];
        $previous_post = '';

        // получаем ID стартового поста
        $start_post_id = (int) $_POST['start_post_id'];

        // получаем направление
        $direct = $_POST['direct'];

        // фильтры для получение
	    $excluded_terms = apply_filters( 'journalx_scroll_load_post_excluded_terms', '', $start_post_id, $post_id, $direct );
	    $taxonomy = apply_filters( 'journalx_scroll_load_post_taxonomy', 'category', $start_post_id, $post_id, $direct );


        // создаем запрос для получения предыдущего
        $posts = new WP_Query( array(
            'p' => $post_id,
            'posts_per_page' => 1,
            'post_status'    => 'publish',
            'post_type'      => apply_filters( 'journalx_scroll_load_post_types', [ 'post' ] ),
        ) );
        while ( $posts->have_posts() ) {
            $posts->the_post();
            if ( $direct == 'next' ) {
                $previous_post = get_next_post( $infinity_scroll_single_category, $excluded_terms, $taxonomy );
            } else {
                $previous_post = get_previous_post( $infinity_scroll_single_category, $excluded_terms, $taxonomy );
            }
        }
        wp_reset_postdata();


        // если предыдущего нет - пытаемся идти в обратную сторону от стартового
        if ( empty( $previous_post ) ) {

            if ( $direct == 'next' ) {
                $direct = 'previous';
            } else {
                $direct = 'next';
            }

            $posts = new WP_Query( array(
                'p' => $start_post_id,
                'posts_per_page' => 1,
                'post_status'    => 'publish',
                'post_type'      => apply_filters( 'journalx_scroll_load_post_types', [ 'post' ] ),
            ) );

            while ( $posts->have_posts() ) {
                $posts->the_post();
                if ( $direct == 'next' ) {
                    $previous_post = get_next_post( $infinity_scroll_single_category, $excluded_terms, $taxonomy );
                } else {
                    $previous_post = get_previous_post( $infinity_scroll_single_category, $excluded_terms, $taxonomy );
                }
            }
            wp_reset_postdata();

            if ( empty( $previous_post ) ) {
                die( 'done' );
            }
        }

        // получаем предыдущий пост
        $posts = new WP_Query( array(
            'p' => $previous_post->ID,
            'posts_per_page' => 1,
            'post_status'    => 'publish',
            'post_type'      => apply_filters( 'journalx_scroll_load_post_types', [ 'post' ] ),
        ) );
        while ( $posts->have_posts() ) {
            global $wp_query;
            $wp_query->is_single = 1;
            $wp_query->is_singular = 1;

	        $wp_query->queried_object    = $posts->post;
	        $wp_query->queried_object_id = $posts->post->ID;

            $posts->the_post();

            do_action( 'wpshop_core_views_counter:count_views' );

            ob_start();
	        set_query_var( 'is_scroll_loaded', 'yes' );


	        /**
	         * Allows to add output of additional content before the main content
	         *
	         * @since 2.1
	         */
	        do_action( 'journalx/scroll/output' );

            get_template_part( 'template/content', 'single' );
            $html = ob_get_contents();

	        ob_end_clean();
            wp_send_json_success( array(
                'html'      => $html,
                'post_id'   => $posts->post->ID,
                'title'     => get_the_title( $posts->post->ID ),
                'url'       => get_the_permalink( $posts->post->ID ),
                'direct'    => $direct,
            ) );
        }

        die();

    }

    /**
     * @return void
     */
    public function _add_wpremark_support() {
        if ( ! class_exists( \Wpshop\WPRemark\PluginContainer::class ) ) {
            return;
        }

        add_filter( 'wpremark/styles/default_styles', '__return_empty_string' );

        add_filter( 'wpremark/styles/content', function ( $content ) {
            if ( $post = get_post() ) {
                $content = $post->post_content;
            }

            return $content;
        } );
        \Wpshop\WPRemark\PluginContainer::get( \Wpshop\WPRemark\Styles::class )->_output_styles();
    }

}

new Scroll();
