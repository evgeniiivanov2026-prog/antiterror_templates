<?php
/**
 * ****************************************************************************
 *
 *   DON'T EDIT THIS FILE
 *   After update you will lose all changes. Use child theme
 *
 *   НЕ РЕДАКТИРУЙТЕ ЭТОТ ФАЙЛ
 *   После обновления Вы потереяете все изменения. Используйте дочернюю тему
 *
 *   https://support.wpshop.ru/docs/general/child-themes/
 *
 * *****************************************************************************
 *
 * @package journalx
 */

global $wpshop_core;

$thumbnail_size = get_post_meta( $post->ID, 'thumbnail_size', true );

$is_show_breadcrumbs = $wpshop_core->is_show_element( 'breadcrumbs' );
$is_show_sidebar     = ( $wpshop_core->get_option( 'structure_single_sidebar' ) && $wpshop_core->is_show_element( 'sidebar' ) );

get_header(); ?>

	<div id="primary" class="content-area" itemscope itemtype="http://schema.org/Article">
		<main id="main" class="site-main">

            <?php
            if ( $thumbnail_size != 'full' && $is_show_breadcrumbs ) {
                get_template_part( 'template/parts/breadcrumbs' );
            }
            ?>

            <?php
            while ( have_posts() ) : the_post();

                get_template_part( 'template/content', 'single' );

            endwhile; // End of the loop.
            ?>

		</main><!-- #main -->
	</div><!-- #primary -->

    <?php if ( $is_show_sidebar ) get_sidebar(); ?>

<?php
get_footer();
