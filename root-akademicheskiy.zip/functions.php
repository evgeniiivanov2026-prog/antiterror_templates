<?php
/**
 * Фонд имени Павла Шевякова — дочерняя тема Root.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'wp_enqueue_scripts', 'shevyakoff_enqueue_assets', 30 );
function shevyakoff_enqueue_assets() {
    wp_enqueue_style(
        'shevyakoff-fonts',
        'https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=PT+Serif:wght@400;700&display=swap&subset=cyrillic',
        array(),
        null
    );
    wp_enqueue_style( 'shevyakoff-theme', get_stylesheet_uri(), array(), '2.0.0' );
    wp_enqueue_script(
        'shevyakoff-site',
        get_stylesheet_directory_uri() . '/assets/js/site.js',
        array(),
        '2.0.0',
        true
    );
}

add_filter( 'body_class', 'shevyakoff_body_class' );
function shevyakoff_body_class( $classes ) {
    $classes[] = 'shevyakoff-site';
    return $classes;
}

add_theme_support( 'title-tag' );

add_action( 'root_after_header', 'shevyakoff_homepage', 20 );
function shevyakoff_homepage() {
    if ( ! is_front_page() || is_paged() ) { return; }
    ?>
    <main id="foundation-home" class="foundation-home">
        <section class="foundation-hero" aria-labelledby="foundation-title">
            <div class="foundation-shell foundation-hero__grid">
                <div class="foundation-hero__copy">
                    <p class="foundation-kicker">Общественная безопасность • Волгоград</p>
                    <h1 id="foundation-title">Защищаем людей.<br><em>Действуем открыто.</em></h1>
                    <p class="foundation-hero__lead">Фонд имени Павла Шевякова объединяет жителей, экспертов и общественные инициативы для противодействия наркоторговле и отравлению населения.</p>
                    <div class="foundation-actions">
                        <a class="foundation-button foundation-button--primary" href="#report">Сообщить информацию <span aria-hidden="true">→</span></a>
                        <a class="foundation-button foundation-button--text" href="#about">О работе фонда <span aria-hidden="true">↘</span></a>
                    </div>
                    <p class="foundation-confidential"><span aria-hidden="true"></span> Конфиденциально. Каждое обращение рассматривается.</p>
                </div>
                <div class="foundation-hero__visual" aria-hidden="true">
                    <div class="foundation-shield">
                        <svg viewBox="0 0 360 440" role="img" aria-label="Символ защиты">
                            <path d="M180 18 326 72v120c0 102-58 183-146 230C92 375 34 294 34 192V72L180 18Z" fill="none" stroke="currentColor" stroke-width="2"/>
                            <path d="M180 62 286 101v91c0 75-40 136-106 176-66-40-106-101-106-176v-91L180 62Z" fill="none" stroke="currentColor" stroke-width="1" opacity=".38"/>
                            <path d="m123 211 39 39 78-91" fill="none" stroke="currentColor" stroke-linecap="square" stroke-width="13"/>
                        </svg>
                    </div>
                    <div class="foundation-hero__note"><span>01</span><p>Безопасная среда начинается с неравнодушия каждого.</p></div>
                </div>
            </div>
        </section>

        <section id="about" class="foundation-section foundation-mission" aria-labelledby="mission-title">
            <div class="foundation-shell foundation-mission__grid">
                <header class="foundation-section__intro">
                    <p class="foundation-section-number">01 / Миссия</p>
                    <h2 id="mission-title">Не оставлять угрозу без ответа</h2>
                </header>
                <div class="foundation-mission__body">
                    <p class="foundation-lede">Мы создаём понятный и ответственный канал для гражданских обращений — без сенсаций, давления и равнодушия.</p>
                    <p>Фонд принимает информацию, помогает систематизировать обращения, развивает профилактические проекты и поддерживает общественный диалог о безопасности.</p>
                    <div class="foundation-principles" role="list">
                        <article role="listitem"><span>А</span><h3>Ответственность</h3><p>Работаем с фактами и бережно относимся к каждому сообщению.</p></article>
                        <article role="listitem"><span>Б</span><h3>Законность</h3><p>Действуем исключительно в правовом поле и взаимодействуем с профильными органами.</p></article>
                        <article role="listitem"><span>В</span><h3>Конфиденциальность</h3><p>Не публикуем персональные данные и чувствительную информацию заявителей.</p></article>
                    </div>
                </div>
            </div>
        </section>

        <section id="directions" class="foundation-section foundation-directions" aria-labelledby="directions-title">
            <div class="foundation-shell">
                <div class="foundation-section__head">
                    <div><p class="foundation-section-number">02 / Направления</p><h2 id="directions-title">Что мы делаем</h2></div>
                    <p>Системная работа вместо разовых акций: от приёма сообщения до общественной профилактики.</p>
                </div>
                <div class="foundation-directions__list">
                    <article><p class="foundation-direction__number">01</p><div><h3>Принимаем обращения</h3><p>Предоставляем безопасный способ сообщить сведения о возможной наркоторговле и угрозах здоровью населения.</p></div><span aria-hidden="true">↗</span></article>
                    <article><p class="foundation-direction__number">02</p><div><h3>Проверяем и направляем</h3><p>Структурируем полученную информацию и передаём её компетентным органам в установленном порядке.</p></div><span aria-hidden="true">↗</span></article>
                    <article><p class="foundation-direction__number">03</p><div><h3>Предупреждаем</h3><p>Готовим материалы для родителей, педагогов и жителей о рисках и признаках опасных ситуаций.</p></div><span aria-hidden="true">↗</span></article>
                    <article><p class="foundation-direction__number">04</p><div><h3>Объединяем общество</h3><p>Поддерживаем инициативы, которые делают городскую среду безопаснее и укрепляют доверие между людьми.</p></div><span aria-hidden="true">↗</span></article>
                </div>
            </div>
        </section>

        <section id="report" class="foundation-report" aria-labelledby="report-title">
            <div class="foundation-shell foundation-report__grid">
                <div>
                    <p class="foundation-section-number foundation-section-number--light">03 / Обращение</p>
                    <h2 id="report-title">Знаете об угрозе?</h2>
                    <p>Передайте информацию фонду. Не вступайте в конфликт и не пытайтесь проводить расследование самостоятельно.</p>
                </div>
                <div class="foundation-report__action">
                    <a class="foundation-button foundation-button--light" href="mailto:info@shevyakoff.ru?subject=Конфиденциальное%20обращение">Написать фонду <span aria-hidden="true">→</span></a>
                    <p>В экстренной ситуации звоните 112.</p>
                </div>
            </div>
        </section>

        <section id="news" class="foundation-section foundation-news" aria-labelledby="news-title">
            <div class="foundation-shell">
                <div class="foundation-section__head">
                    <div><p class="foundation-section-number">04 / Публикации</p><h2 id="news-title">Новости фонда</h2></div>
                    <a href="<?php echo esc_url( get_permalink( get_option( 'page_for_posts' ) ) ?: home_url( '/' ) ); ?>">Все публикации <span aria-hidden="true">→</span></a>
                </div>
                <?php
                $news = new WP_Query( array( 'post_type' => 'post', 'posts_per_page' => 3, 'post_status' => 'publish' ) );
                if ( $news->have_posts() ) : ?>
                    <div class="foundation-news__grid">
                        <?php while ( $news->have_posts() ) : $news->the_post(); ?>
                            <article>
                                <p class="foundation-news__date"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'd.m.Y' ) ); ?></time></p>
                                <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                <p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 22 ) ); ?></p>
                                <a class="foundation-news__link" href="<?php the_permalink(); ?>" aria-label="Читать: <?php echo esc_attr( get_the_title() ); ?>">Читать <span aria-hidden="true">↗</span></a>
                            </article>
                        <?php endwhile; wp_reset_postdata(); ?>
                    </div>
                <?php else : ?>
                    <div class="foundation-news__empty"><p>Здесь появятся новости, отчёты и материалы фонда.</p></div>
                <?php endif; ?>
            </div>
        </section>
    </main>
    <?php
}

add_filter( 'root_site_content_classes', 'shevyakoff_content_classes', 50 );
function shevyakoff_content_classes( $classes ) {
    if ( is_front_page() ) { return trim( $classes . ' foundation-original-feed' ); }
    return $classes;
}

add_action( 'wp_head', 'shevyakoff_meta', 2 );
function shevyakoff_meta() {
    echo '<meta name="theme-color" content="#16233a">' . "\n";
}
