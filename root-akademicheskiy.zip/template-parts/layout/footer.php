<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
do_action( THEME_SLUG . '_before_footer' );
?>
<footer id="site-footer" class="site-footer" itemscope itemtype="https://schema.org/WPFooter">
    <div class="foundation-shell site-footer__grid">
        <div class="site-footer__brand">
            <a class="site-logo site-logo--footer" href="<?php echo esc_url( home_url( '/' ) ); ?>">
                <svg class="site-logo__mark" viewBox="0 0 52 60" aria-hidden="true"><path d="M26 2 49 11v18c0 13-8 24-23 29C11 53 3 42 3 29V11L26 2Z" fill="none" stroke="currentColor" stroke-width="2"/><path d="m15 29 7 7 15-18" fill="none" stroke="currentColor" stroke-width="4"/></svg>
                <span class="site-logo__text"><strong>Фонд имени</strong><b>Павла Шевякова</b></span>
            </a>
            <p>Противодействие наркоторговле и защита здоровья населения.</p>
        </div>
        <nav class="site-footer__nav" aria-label="Навигация в подвале">
            <p>Разделы</p><a href="<?php echo esc_url( home_url( '/#about' ) ); ?>">О фонде</a><a href="<?php echo esc_url( home_url( '/#directions' ) ); ?>">Направления</a><a href="<?php echo esc_url( home_url( '/#news' ) ); ?>">Новости</a>
        </nav>
        <div class="site-footer__contacts"><p>Связаться</p><a href="mailto:info@shevyakoff.ru">info@shevyakoff.ru</a><a href="<?php echo esc_url( home_url( '/#report' ) ); ?>">Передать информацию</a></div>
    </div>
    <div class="foundation-shell site-footer__bottom"><span>© <?php echo esc_html( date( 'Y' ) ); ?> Фонд имени Павла Шевякова</span><span>Информация на сайте не заменяет обращение в экстренные службы</span></div>
</footer>
<?php do_action( THEME_SLUG . '_after_footer' ); ?>
