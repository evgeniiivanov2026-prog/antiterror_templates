(function () {
  document.documentElement.classList.add('has-js');
  var root = document.documentElement;
  var themeButton = document.querySelector('[data-theme-toggle]');
  var dark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  root.setAttribute('data-theme', dark ? 'dark' : 'light');
  if (themeButton) {
    themeButton.addEventListener('click', function () {
      dark = root.getAttribute('data-theme') !== 'dark';
      root.setAttribute('data-theme', dark ? 'dark' : 'light');
      themeButton.setAttribute('aria-label', dark ? 'Включить светлую тему' : 'Включить тёмную тему');
    });
  }

  var menuButton = document.querySelector('.mob-hamburger');
  var mobileMenu = document.getElementById('site-mobile-menu');
  if (menuButton && mobileMenu) {
    menuButton.addEventListener('click', function () {
      var open = menuButton.getAttribute('aria-expanded') === 'true';
      menuButton.setAttribute('aria-expanded', String(!open));
      menuButton.setAttribute('aria-label', open ? 'Открыть меню' : 'Закрыть меню');
      mobileMenu.hidden = open;
    });
    mobileMenu.addEventListener('click', function (event) {
      if (event.target.closest('a')) {
        menuButton.setAttribute('aria-expanded', 'false');
        menuButton.setAttribute('aria-label', 'Открыть меню');
        mobileMenu.hidden = true;
      }
    });
  }

  var targets = document.querySelectorAll('.foundation-section__intro,.foundation-mission__body,.foundation-section__head,.foundation-directions__list article,.foundation-news__grid article');
  if ('IntersectionObserver' in window) {
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) { entry.target.classList.add('is-visible'); observer.unobserve(entry.target); }
      });
    }, { threshold: 0.12 });
    targets.forEach(function (target, index) { target.style.transitionDelay = Math.min(index % 4, 3) * 70 + 'ms'; observer.observe(target); });
  } else { targets.forEach(function (target) { target.classList.add('is-visible'); }); }
}());
